[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/v_kcaj0E)
# R4.04 2023-2024 - Kaiju vs Gundam

## Description

Ce projet est une API de jeu de combat entre Kaiju et Gundam.

## Installation

Pour installer le projet, il faut cloner le repository et installer les dépendances avec la commande suivante :

```bash
mvn clean install
```

## Reste à faire

### Kaiju

- Creer les tests unitaires & fonctionnels manquants selon les spécifications du projet stockés dans le dossier `docs`

### Gundam
- Creer le code applicatif manquant selon les spécifications du projet stockés dans le dossier `docs`
- Creer les tests unitaires & fonctionnels manquants selon les spécifications du projet stockés dans le dossier `docs`

### Systeme de combat
- Creer le code applicatif manquant selon les spécifications du projet stockés dans le dossier `docs`
- Creer les tests unitaires & fonctionnels manquants selon les spécifications du projet stockés dans le dossier `docs`