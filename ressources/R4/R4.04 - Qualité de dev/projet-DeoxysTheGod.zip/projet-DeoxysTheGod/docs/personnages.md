# Personnages

## Règles de base

### Défense

#### En cas de défense négative

La défense est mise à 0