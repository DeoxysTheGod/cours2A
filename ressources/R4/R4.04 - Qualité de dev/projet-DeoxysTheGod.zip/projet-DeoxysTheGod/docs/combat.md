# Système de combat

## Description

Le système de combat est un système tour par tour

### Combat
Un combat comprend 2 combattants, un Kaiju et un Gundam.
Un combat a un statut, qui peut être `IN_PROGRESS`, `FINISHED` ou `CANCELLED`.
Un combat a un ID au format UUID.

### Création d'un combat

Route : `POST /battle/create`

Payload : 

```json
{
    "kaijuId": "d290f1ee-6c54-4b01-90e6-d701748f0851",
    "gundamId": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"
}
```

Response : 
```json
{
  "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
  "turn": 0,
  "status": "IN_PROGRESS",
  "kaiju": {
    "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
    "name": "Godzilla",
    "health": 100,
    "attack": 10,
    "defense": 5,
    "speed": 5
  },
  "gundam": {
    "id": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
    "name": "RX-78-2",
    "health": 100,
    "attack": 10,
    "defense": 5,
    "speed": 5
  }
}
```
Cette route doit créer un combat entre un Kaiju et un Gundam. Puis renvoyer le combat créé.

### Lancement d'un tour

Route : `POST /battle/{battleId}/turn`

Response : 
```json
{
  "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
  "turn": 1,
  "status": "IN_PROGRESS",
  "kaiju": {
    "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
    "name": "Godzilla",
    "health": 90,
    "attack": 10,
    "defense": 5,
    "speed": 5
  },
  "gundam": {
    "id": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
    "name": "RX-78-2",
    "health": 90,
    "attack": 10,
    "defense": 5,
    "speed": 5
  }
}
```

Cette route doit lancer un tour de combat. Celui qui a la vitesse la plus grande attaque en premier.

Les attaques doivent prendre en compte la précision de l'attaquant.


### Fin du combat
La combat se termine quand un des combattants n'a plus de vie.

Route : `GET /battle/{battleId}/end`

Response : 
```json
{
  "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
  "turn": 1,
  "status": "FINISHED",
  "kaiju": {
    "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
    "name": "Godzilla",
    "health": 90,
    "attack": 10,
    "defense": 5,
    "speed": 5
  },
  "gundam": {
    "id": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
    "name": "RX-78-2",
    "health": 0,
    "attack": 10,
    "defense": 5,
    "speed": 5
  },
  "winner": "d290f1ee-6c54-4b01-90e6-d701748f0851",
  "turns": [
    {
      "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
      "turn": 1,
      "status": "IN_PROGRESS",
      "kaiju": {
        "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
        "name": "Godzilla",
        "health": 100,
        "attack": 10,
        "defense": 5,
        "speed": 5
      },
      "gundam": {
        "id": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
        "name": "RX-78-2",
        "health": 100,
        "attack": 10,
        "defense": 5,
        "speed": 5
      },
        "actions": [
            {
            "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
            "type": "ATTACK",
            "source": "d290f1ee-6c54-4b01-90e6-d701748f0851",
            "target": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
            "value": 10
            },
          {
            "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
            "type": "ATTACK",
            "source": "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
            "target": "d290f1ee-6c54-4b01-90e6-d701748f0851",
            "value": 10
          }
        ]
    }
  ]
}
```

