# Gundam


## Règles spécifiques

### Vitesse

La vitesse est multiplié par 1,5

### Dommages infligés

Les dommages infligés sont multipliés par 1,5