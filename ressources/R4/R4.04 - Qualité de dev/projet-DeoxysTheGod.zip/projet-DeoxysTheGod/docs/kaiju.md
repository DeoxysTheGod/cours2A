# Kaiju

## Règles spécifiques

### Précision 

La précision est divisé par 2

### Dommages reçus

Les dommages reçus sont divisés par 2