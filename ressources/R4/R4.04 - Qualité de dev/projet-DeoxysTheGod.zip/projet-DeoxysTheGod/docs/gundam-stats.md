# Gundam stats - Statistics values for gundam

## Kaiju stats
//Randomly generated stats for Kaiju


| Name                                 | Health | Attack | Defense | Speed | Critical Chance | Evade Chance | Accuracy |
|--------------------------------------|--------|--------|---------|-------|-----------------|--------------|----------|
| RX_78_2                              | 125    | 55     | 86      | 62    | 84              | 26           | 12       |
| ZAKU_II                              | 440    | 43     | 88      | 16    | 73              | 29           | 11       |
| ZAKU_II_HIGH_MOBILITY                | 317    | 34     | 60      | 76    | 89              | 55           | 52       |
| GUNDAM_BARBATOS                      | 758    | 23     | 65      | 58    | 93              | 8            | 71       |
| GUNDAM_BARBATOS_LUPUS                | 245    | 34     | 8       | 45    | 99              | 69           | 37       |
| GUNDAM_BARBATOS_LUPUS_REX            | 989    | 95     | 36      | 21    | 69              | 41           | 11       |
| GUNDAM_ASTRAY_RED_FRAME              | 791    | 83     | 97      | 37    | 79              | 64           | 21       |
| GUNDAM_ASTRAY_BLUE_FRAME             | 448    | 19     | 41      | 47    | 8               | 23           | 82       |
| GUNDAM_ASTRAY_GOLD_FRAME_AMATSU      | 528    | 74     | 42      | 29    | 37              | 78           | 77       |
| GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA | 926    | 13     | 9       | 20    | 10              | 84           | 80       |
| GUNDAM_EXIA                          | 142    | 84     | 32      | 75    | 21              | 87           | 48       |
| GUNDAM_EXIA_REPAIR                   | 595    | 98     | 62      | 84    | 18              | 15           | 16       |
| GUNDAM_EXIA_REPAIR_II                | 231    | 94     | 50      | 38    | 82              | 22           | 86       |
| GUNDAM_EXIA_DARK_MATTER              | 379    | 100    | 34      | 88    | 100             | 51           | 63       |
| GUNDAM_DYNAMES                       | 248    | 48     | 74      | 50    | 52              | 49           | 89       |
| GUNDAM_WING_ZERO                     | 490    | 28     | 18      | 55    | 20              | 9            | 22       |
| GUNDAM_EPYON                         | 803    | 18     | 67      | 30    | 84              | 72           | 97       |
| GUNDAM_HEAVYARMS                     | 131    | 11     | 66      | 79    | 92              | 11           | 70       |
| GUNDAM_SANDROCK                      | 297    | 64     | 91      | 46    | 91              | 5            | 100      |
| TALLGEESE                            | 486    | 41     | 85      | 28    | 48              | 39           | 47       |