package fr.aix.but.r404_20232024.application.query.gundam.listGundamModel;

public class ListGundamModel {
}
