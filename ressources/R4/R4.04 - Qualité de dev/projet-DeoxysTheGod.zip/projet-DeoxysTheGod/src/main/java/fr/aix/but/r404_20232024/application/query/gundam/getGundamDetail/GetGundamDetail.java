package fr.aix.but.r404_20232024.application.query.gundam.getGundamDetail;

public class GetGundamDetail {
    private String id;

    public GetGundamDetail(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
