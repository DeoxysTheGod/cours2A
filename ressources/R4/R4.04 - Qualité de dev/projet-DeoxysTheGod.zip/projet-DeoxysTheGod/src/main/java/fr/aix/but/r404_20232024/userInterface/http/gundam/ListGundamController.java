package fr.aix.but.r404_20232024.userInterface.http.gundam;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.query.gundam.listGundam.ListGundam;
import fr.aix.but.r404_20232024.application.query.gundam.listGundam.ListGundamHandler;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/gundam")
public class ListGundamController {
    private ListGundamHandler listGundamHandler;
    private Gson gson;

    @Autowired
    public ListGundamController(ListGundamHandler listGundamHandler) {
        this.listGundamHandler = listGundamHandler;
        this.gson = new Gson();
    }

    @GetMapping("/list")
    public String listGundam() {
        List<GundamReadModel> gundamReadModels = listGundamHandler.handle(new ListGundam());
        return gson.toJson(gundamReadModels);
    }
}
