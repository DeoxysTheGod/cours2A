package fr.aix.but.r404_20232024.application.query.kaiju.listKaijuType;

import fr.aix.but.r404_20232024.domain.kaiju.KaijuType;
import org.springframework.stereotype.Component;

@Component
public class ListKaijuTypeHandler {
    public ListKaijuTypeHandler() {
    }

    public KaijuType[] handle(ListKaijuType query) {
        return KaijuType.values();
    }
}
