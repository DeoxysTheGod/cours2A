package fr.aix.but.r404_20232024.application.command.battle.createBattle;

import fr.aix.but.r404_20232024.domain.battle.Battle;
import fr.aix.but.r404_20232024.domain.battle.BattleFactory;
import fr.aix.but.r404_20232024.domain.battle.BattleRepository;
import fr.aix.but.r404_20232024.domain.battle.readModel.BattleReadModel;
import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.springframework.stereotype.Component;

@Component
public class CreateBattleHandler {

    BattleRepository battleRepository;
    BattleFactory battleFactory;

    KaijuRepository kaijuRepository;
    GundamRepository gundamRepository;

    public CreateBattleHandler(BattleRepository battleRepository, BattleFactory battleFactory, KaijuRepository kaijuRepository, GundamRepository gundamRepository) {
        this.battleRepository = battleRepository;
        this.battleFactory = battleFactory;
        this.kaijuRepository = kaijuRepository;
        this.gundamRepository = gundamRepository;
    }

    public BattleReadModel handle(CreateBattle createBattle) {
        Kaiju kaiju = kaijuRepository.find(createBattle.getKaijuId());
        Gundam gundam = gundamRepository.find(createBattle.getGundamId());

        Battle battle = battleFactory.createBattle(kaiju, gundam);
        battleRepository.save(battle);

        return battle.readModel();
    }
}
