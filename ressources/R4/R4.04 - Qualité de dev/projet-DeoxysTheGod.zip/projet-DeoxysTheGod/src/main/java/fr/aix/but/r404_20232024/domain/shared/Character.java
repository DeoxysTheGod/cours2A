package fr.aix.but.r404_20232024.domain.shared;

public interface Character
{
   String getName();
    int getHealth();
    int getMaxHealth();
    int getAttack();
    int getDefense();
    int getSpeed();
    int getCriticalChance();
    int getEvadeChance();
    int getAccuracy();
    int takeDamage(int damage);

    Id getId();

}
