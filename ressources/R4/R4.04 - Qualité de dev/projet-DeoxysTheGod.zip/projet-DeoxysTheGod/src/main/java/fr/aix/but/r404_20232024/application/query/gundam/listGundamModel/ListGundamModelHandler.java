package fr.aix.but.r404_20232024.application.query.gundam.listGundamModel;

import fr.aix.but.r404_20232024.application.query.gundam.listGundamModel.ListGundamModel;
import fr.aix.but.r404_20232024.domain.gundam.GundamModel;
import org.springframework.stereotype.Component;

@Component
public class ListGundamModelHandler {
    public ListGundamModelHandler() {
    }

    public GundamModel[] handle(ListGundamModel query) {
        return GundamModel.values();
    }
}