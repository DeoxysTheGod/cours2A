package fr.aix.but.r404_20232024.userInterface.http.battle;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/battle")
public class LaunchTurnController {

        @PostMapping("/launch-turn")
        public String launchTurn() {
            return "OK";
        }
}
