package fr.aix.but.r404_20232024.domain.gundam;

public enum GundamModel {
    RX_78_2("RX-78-2"),
    ZAKU_II("Zaku II"),
    ZAKU_II_HIGH_MOBILITY("Zaku II High Mobility"),
    GUNDAM_BARBATOS("Gundam Barbatos"),
    GUNDAM_BARBATOS_LUPUS("Gundam Barbatos Lupus"),
    GUNDAM_BARBATOS_LUPUS_REX("Gundam Barbatos Lupus Rex"),
    GUNDAM_ASTRAY_RED_FRAME("Gundam Astray Red Frame"),
    GUNDAM_ASTRAY_BLUE_FRAME("Gundam Astray Blue Frame"),
    GUNDAM_ASTRAY_GOLD_FRAME_AMATSU("Gundam Astray Gold Frame Amatsu"),
    GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA("Gundam Astray Gold Frame Amatsu Mina"),
    GUNDAM_EXIA("Gundam Exia"),
    GUNDAM_EXIA_REPAIR("Gundam Exia Repair"),
    GUNDAM_EXIA_REPAIR_II("Gundam Exia Repair II"),
    GUNDAM_EXIA_DARK_MATTER("Gundam Exia Dark Matter"),
    GUNDAM_DYNAMES("Gundam Dynames"),
    GUNDAM_WING_ZERO("Gundam Wing Zero"),
    GUNDAM_EPYON("Gundam Epyon"),
    GUNDAM_HEAVYARMS("Gundam Heavyarms"),
    GUNDAM_SANDROCK("Gundam Sandrock"),
    TALLGEESE("Tallgeese");
    private final String value;

    GundamModel(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
