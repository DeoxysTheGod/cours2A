package fr.aix.but.r404_20232024.domain.gundam;

public record GundamStats(int maxHealth, int attack, int defense, int speed, int criticalChance, int evadeChance,
                          int accuracy) {
}
