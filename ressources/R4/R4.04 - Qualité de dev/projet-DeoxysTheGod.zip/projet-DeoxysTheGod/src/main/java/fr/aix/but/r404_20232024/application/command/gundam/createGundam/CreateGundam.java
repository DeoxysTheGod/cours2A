package fr.aix.but.r404_20232024.application.command.gundam.createGundam;

public class CreateGundam {
    private String name;
    public String model;

    public CreateGundam(String name, String model) {
        this.name = name;
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public String getModel() {
        return model;
    }
}
