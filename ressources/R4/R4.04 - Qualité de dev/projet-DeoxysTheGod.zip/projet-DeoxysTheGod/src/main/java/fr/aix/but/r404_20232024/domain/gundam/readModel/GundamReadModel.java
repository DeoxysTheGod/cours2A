package fr.aix.but.r404_20232024.domain.gundam.readModel;

public class GundamReadModel {
    private final String model;
    private final String id;
    private final String name;

    private final int maxHealth;
    private final int currentHealth;

    private final int attack;

    private final int defense;

    private final int speed;

    private final int criticalChance;

    private final int evadeChance;

    private final int accuracy;

    public GundamReadModel(String id, String name, String model, int maxHealth, int currentHealth, int attack, int defense, int speed, int criticalChance, int evadeChance, int accuracy) {
        this.id = id;
        this.name = name;
        this.model = model;
        this.maxHealth = maxHealth;
        this.currentHealth = currentHealth;
        this.attack = attack;
        this.defense = defense;
        this.speed = speed;
        this.criticalChance = criticalChance;
        this.evadeChance = evadeChance;
        this.accuracy = accuracy;
    }

    public String getModel() {
        return model;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public int getCurrentHealth() {
        return currentHealth;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpeed() {
        return speed;
    }

    public int getCriticalChance() {
        return criticalChance;
    }

    public int getEvadeChance() {
        return evadeChance;
    }

    public int getAccuracy() {
        return accuracy;
    }
}
