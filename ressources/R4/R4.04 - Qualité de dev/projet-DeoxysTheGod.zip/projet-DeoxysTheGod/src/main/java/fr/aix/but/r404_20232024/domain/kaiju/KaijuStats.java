package fr.aix.but.r404_20232024.domain.kaiju;

public record KaijuStats(int maxHealth, int attack, int defense, int speed, int criticalChance, int evadeChance,
                         int accuracy) {
}
