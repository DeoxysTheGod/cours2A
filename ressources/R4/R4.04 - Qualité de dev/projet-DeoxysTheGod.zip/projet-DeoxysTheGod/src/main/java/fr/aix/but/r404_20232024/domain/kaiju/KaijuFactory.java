package fr.aix.but.r404_20232024.domain.kaiju;

import org.springframework.stereotype.Component;

@Component
public class KaijuFactory {
    private final KaijuStatsRepository kaijuStatsRepository;

    public KaijuFactory(KaijuStatsRepository kaijuStatsRepository) {
        this.kaijuStatsRepository = kaijuStatsRepository;
    }

    public Kaiju fromType(String type, String name) {
        return switch (KaijuType.valueOf(type)) {
            case ANGUIRUS -> Kaiju.create(name, KaijuType.ANGUIRUS, kaijuStatsRepository.fromType(KaijuType.ANGUIRUS));
            case BARAGON -> Kaiju.create(name, KaijuType.BARAGON, kaijuStatsRepository.fromType(KaijuType.BARAGON));
            case BATTRA -> Kaiju.create(name, KaijuType.BATTRA, kaijuStatsRepository.fromType(KaijuType.BATTRA));
            case BIOLLANTE -> Kaiju.create(name, KaijuType.BIOLLANTE, kaijuStatsRepository.fromType(KaijuType.BIOLLANTE));
            case DESTOROYAH -> Kaiju.create(name, KaijuType.DESTOROYAH, kaijuStatsRepository.fromType(KaijuType.DESTOROYAH));
            case EBIRAH -> Kaiju.create(name, KaijuType.EBIRAH, kaijuStatsRepository.fromType(KaijuType.EBIRAH));
            case GABARA -> Kaiju.create(name, KaijuType.GABARA, kaijuStatsRepository.fromType(KaijuType.GABARA));
            case GANIMES -> Kaiju.create(name, KaijuType.GANIMES, kaijuStatsRepository.fromType(KaijuType.GANIMES));
            case GIGAN -> Kaiju.create(name, KaijuType.GIGAN, kaijuStatsRepository.fromType(KaijuType.GIGAN));
            case GODZILLA -> Kaiju.create(name, KaijuType.GODZILLA, kaijuStatsRepository.fromType(KaijuType.GODZILLA));
            case GOROSAURUS -> Kaiju.create(name, KaijuType.GOROSAURUS, kaijuStatsRepository.fromType(KaijuType.GOROSAURUS));
            case GYAOS -> Kaiju.create(name, KaijuType.GYAOS, kaijuStatsRepository.fromType(KaijuType.GYAOS));
            case HEDORAH -> Kaiju.create(name, KaijuType.HEDORAH, kaijuStatsRepository.fromType(KaijuType.HEDORAH));
            case IRYS -> Kaiju.create(name, KaijuType.IRYS, kaijuStatsRepository.fromType(KaijuType.IRYS));
            case KAMACURAS -> Kaiju.create(name, KaijuType.KAMACURAS, kaijuStatsRepository.fromType(KaijuType.KAMACURAS));
            case KAMOEBAS -> Kaiju.create(name, KaijuType.KAMOEBAS, kaijuStatsRepository.fromType(KaijuType.KAMOEBAS));
            case KING_CAESAR -> Kaiju.create(name, KaijuType.KING_CAESAR, kaijuStatsRepository.fromType(KaijuType.KING_CAESAR));
            case KING_KONG -> Kaiju.create(name, KaijuType.KING_KONG, kaijuStatsRepository.fromType(KaijuType.KING_KONG));
            case KUMONGA -> Kaiju.create(name, KaijuType.KUMONGA, kaijuStatsRepository.fromType(KaijuType.KUMONGA));
            case LEGION -> Kaiju.create(name, KaijuType.LEGION, kaijuStatsRepository.fromType(KaijuType.LEGION));
            case MAGUMA -> Kaiju.create(name, KaijuType.MAGUMA, kaijuStatsRepository.fromType(KaijuType.MAGUMA));
            case MANDA -> Kaiju.create(name, KaijuType.MANDA, kaijuStatsRepository.fromType(KaijuType.MANDA));
            case MATANGO -> Kaiju.create(name, KaijuType.MATANGO, kaijuStatsRepository.fromType(KaijuType.MATANGO));
            case MECHAGODZILLA -> Kaiju.create(name, KaijuType.MECHAGODZILLA, kaijuStatsRepository.fromType(KaijuType.MECHAGODZILLA));
            case MECHANI_KONG -> Kaiju.create(name, KaijuType.MECHANI_KONG, kaijuStatsRepository.fromType(KaijuType.MECHANI_KONG));
            case MEGALON -> Kaiju.create(name, KaijuType.MEGALON, kaijuStatsRepository.fromType(KaijuType.MEGALON));
            case MINILLA -> Kaiju.create(name, KaijuType.MINILLA, kaijuStatsRepository.fromType(KaijuType.MINILLA));
            case MOGERA -> Kaiju.create(name, KaijuType.MOGERA, kaijuStatsRepository.fromType(KaijuType.MOGERA));
            case MOGUERA -> Kaiju.create(name, KaijuType.MOGUERA, kaijuStatsRepository.fromType(KaijuType.MOGUERA));
            case MOTHRA -> Kaiju.create(name, KaijuType.MOTHRA, kaijuStatsRepository.fromType(KaijuType.MOTHRA));
            case OODAKA -> Kaiju.create(name, KaijuType.OODAKA, kaijuStatsRepository.fromType(KaijuType.OODAKA));
            case ORGA -> Kaiju.create(name, KaijuType.ORGA, kaijuStatsRepository.fromType(KaijuType.ORGA));
            case RATTLESNAKE -> Kaiju.create(name, KaijuType.RATTLESNAKE, kaijuStatsRepository.fromType(KaijuType.RATTLESNAKE));
            case RODAN -> Kaiju.create(name, KaijuType.RODAN, kaijuStatsRepository.fromType(KaijuType.RODAN));
            case SPACE_GODZILLA -> Kaiju.create(name, KaijuType.SPACE_GODZILLA, kaijuStatsRepository.fromType(KaijuType.SPACE_GODZILLA));
            case TITANOSAURUS -> Kaiju.create(name, KaijuType.TITANOSAURUS, kaijuStatsRepository.fromType(KaijuType.TITANOSAURUS));
            case VARAN -> Kaiju.create(name, KaijuType.VARAN, kaijuStatsRepository.fromType(KaijuType.VARAN));
            case ZIGRA -> Kaiju.create(name, KaijuType.ZIGRA, kaijuStatsRepository.fromType(KaijuType.ZIGRA));
            case ZILLA -> Kaiju.create(name, KaijuType.ZILLA, kaijuStatsRepository.fromType(KaijuType.ZILLA));
            case ZONE_FIGHTER -> Kaiju.create(name, KaijuType.ZONE_FIGHTER, kaijuStatsRepository.fromType(KaijuType.ZONE_FIGHTER));
            default -> throw new IllegalArgumentException("Unknown type");
        };
    }
}
