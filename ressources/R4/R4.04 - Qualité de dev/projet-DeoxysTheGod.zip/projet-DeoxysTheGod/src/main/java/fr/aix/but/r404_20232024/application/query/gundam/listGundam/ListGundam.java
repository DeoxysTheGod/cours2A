package fr.aix.but.r404_20232024.application.query.gundam.listGundam;

public class ListGundam {
}
