package fr.aix.but.r404_20232024.application.command.battle.createBattle;

public class CreateBattle {
    private String kaijuId;
    private String gundamId;
}
