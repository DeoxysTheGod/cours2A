package fr.aix.but.r404_20232024.application.command.battle.createBattle;

import fr.aix.but.r404_20232024.domain.shared.Id;

public class CreateBattle {
    private Id kaijuId;
    private Id gundamId;

    public CreateBattle(Id kaijuId, Id gundamId) {
        this.kaijuId = kaijuId;
        this.gundamId = gundamId;
    }

    public Id getKaijuId() {
        return kaijuId;
    }

    public Id getGundamId() {
        return gundamId;
    }

    public String getKaijuIdToString() {
        return kaijuId.getId();
    }

    public String getGundamIdToString() {
        return gundamId.getId();
    }
}
