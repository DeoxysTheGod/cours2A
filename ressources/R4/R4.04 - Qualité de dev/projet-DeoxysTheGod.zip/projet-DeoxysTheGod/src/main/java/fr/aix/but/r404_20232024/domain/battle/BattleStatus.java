package fr.aix.but.r404_20232024.domain.battle;

public enum BattleStatus {
    IN_PROGRESS("IN_PROGRESS"),
    FINISHED("FINISHED"),
    CANCELLED("CANCELLED");

    private final String value;

    BattleStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
