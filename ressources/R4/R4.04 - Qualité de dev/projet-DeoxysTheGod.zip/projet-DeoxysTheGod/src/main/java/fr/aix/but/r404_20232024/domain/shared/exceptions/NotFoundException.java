package fr.aix.but.r404_20232024.domain.shared.exceptions;

import java.text.MessageFormat;

public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }

    public static NotFoundException kaijuNotFound(String id) {
        return new NotFoundException(MessageFormat.format("Kaiju with id {0} not found", id));
    }

    public static NotFoundException gundamNotFound(String id) {
        return new NotFoundException(MessageFormat.format("Gundam with id {0} not found", id));
    }
}
