package fr.aix.but.r404_20232024.application.command.gundam.createGundam;

import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.GundamFactory;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import org.springframework.stereotype.Component;

@Component
public class CreateGundamHandler {

    GundamRepository gundamRepository;
    GundamFactory gundamFactory;

    public CreateGundamHandler(GundamRepository gundamRepository, GundamFactory gundamFactory) {
        this.gundamRepository = gundamRepository;
        this.gundamFactory = gundamFactory;
    }

    public GundamReadModel handle(CreateGundam createGundam) {
        Gundam gundam = gundamFactory.fromType(createGundam.getModel(), createGundam.getName());

        gundamRepository.save(gundam);
        return gundam.readModel();
    }
}
