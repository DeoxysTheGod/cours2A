package fr.aix.but.r404_20232024.domain.gundam;

import org.springframework.stereotype.Component;

@Component
public class GundamStatsRepository {
    public GundamStats fromType(GundamModel model) {
        return switch (model) {
            case RX_78_2 -> new GundamStats(125, 55, 86, 62, 84, 26, 12);
            case ZAKU_II -> new GundamStats(440, 43, 88, 16, 73, 29, 11);
            case ZAKU_II_HIGH_MOBILITY -> new GundamStats(317, 34, 60, 76, 89, 55, 52);
            case GUNDAM_BARBATOS -> new GundamStats(758, 23, 65, 58, 93, 8, 71);
            case GUNDAM_BARBATOS_LUPUS -> new GundamStats(245, 34, 8, 45, 99, 69, 37);
            case GUNDAM_BARBATOS_LUPUS_REX -> new GundamStats(989, 95, 36, 21, 69, 41, 11);
            case GUNDAM_ASTRAY_RED_FRAME -> new GundamStats(791, 83, 97, 37, 79, 64, 21);
            case GUNDAM_ASTRAY_BLUE_FRAME -> new GundamStats(448, 19, 41, 47, 8, 23, 82);
            case GUNDAM_ASTRAY_GOLD_FRAME_AMATSU -> new GundamStats(528, 74, 42, 29, 37, 78, 77);
            case GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA -> new GundamStats(926, 13, 9, 20, 10, 84, 80);
            case GUNDAM_EXIA -> new GundamStats(142, 84, 32, 75, 21, 87, 48);
            case GUNDAM_EXIA_REPAIR -> new GundamStats(595, 98, 62, 84, 18, 15, 16);
            case GUNDAM_EXIA_REPAIR_II -> new GundamStats(231, 94, 50, 38, 82, 22, 86);
            case GUNDAM_EXIA_DARK_MATTER -> new GundamStats(379, 100, 34, 88, 100, 51, 63);
            case GUNDAM_DYNAMES -> new GundamStats(248, 48, 74, 50, 52, 49, 89);
            case GUNDAM_WING_ZERO -> new GundamStats(490, 28, 18, 55, 20, 9, 22);
            case GUNDAM_EPYON -> new GundamStats(803, 18, 67, 30, 84, 72, 97);
            case GUNDAM_HEAVYARMS -> new GundamStats(131, 11, 66, 79, 92, 11, 70);
            case GUNDAM_SANDROCK -> new GundamStats(297, 64, 91, 46, 91, 5, 100);
            case TALLGEESE -> new GundamStats(486, 41, 85, 28, 48, 39, 47);

            default -> throw new IllegalArgumentException("Unknown type");
        };
    }
}
