package fr.aix.but.r404_20232024.userInterface.http.gundam;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.query.gundam.getGundamDetail.GetGundamDetail;
import fr.aix.but.r404_20232024.application.query.gundam.getGundamDetail.GetGundamDetailHandler;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/gundam")
public class GetGundamDetailController {
    private GetGundamDetailHandler getGundamDetailHandler;
    private Gson gson;

    @Autowired
    public GetGundamDetailController(GetGundamDetailHandler getGundamDetailHandler) {
        this.getGundamDetailHandler = getGundamDetailHandler;
        this.gson = new Gson();
    }

    @GetMapping("{id}/detail")
    public String getGundamDetail(@PathVariable String id) {
        try {
            return gson.toJson(getGundamDetailHandler.handle(new GetGundamDetail(id)));

        } catch (NotFoundException e) {

            throw new ResponseStatusException(
                    org.springframework.http.HttpStatus.NOT_FOUND, "Gundam not found", e);
        }
    }
}

