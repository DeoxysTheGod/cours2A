package fr.aix.but.r404_20232024.userInterface.http.kaiju;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.query.kaiju.listKaijuType.ListKaijuType;
import fr.aix.but.r404_20232024.application.query.kaiju.listKaijuType.ListKaijuTypeHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/kaiju")
public class ListKaijuTypeController {
    private ListKaijuTypeHandler listKaijuTypeHandler;

    private Gson gson;

    @Autowired
    public ListKaijuTypeController(ListKaijuTypeHandler listKaijuTypeHandler) {
        this.listKaijuTypeHandler = listKaijuTypeHandler;
        this.gson = new Gson();
    }

    @GetMapping("/list-type")
    public String listKaijuType() {
        return gson.toJson(listKaijuTypeHandler.handle(new ListKaijuType()));
    }
}
