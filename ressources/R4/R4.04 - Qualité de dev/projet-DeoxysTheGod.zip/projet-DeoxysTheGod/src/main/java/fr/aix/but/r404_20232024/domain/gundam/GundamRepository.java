package fr.aix.but.r404_20232024.domain.gundam;

import fr.aix.but.r404_20232024.domain.shared.Id;

import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public interface GundamRepository {
    void save(Gundam gundam);
    Gundam find(Id id);

    List<Gundam> getAllGundam();

    void deleteGundam(Id id);

    void deleteAllGundam();
}
