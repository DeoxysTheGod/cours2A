package fr.aix.but.r404_20232024.application.query.kaiju.listKaiju;

public class ListKaiju {

}
