package fr.aix.but.r404_20232024.userInterface.http.battle;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.command.battle.createBattle.CreateBattle;
import fr.aix.but.r404_20232024.application.command.battle.createBattle.CreateBattleHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/battle")
public class CreateBattleController {
    private CreateBattleHandler createBattleHandler;
    private Gson gson;

    @Autowired
    public CreateBattleController(CreateBattleHandler createBattleHandler) {
        this.createBattleHandler = createBattleHandler;
        this.gson = new Gson();
    }

    @PostMapping(value = "/create", consumes = {"application/json"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> createBattle(@RequestBody CreateBattle createBattle) {
        return ResponseEntity.ok(gson.toJson(createBattleHandler.handle(createBattle)));
    }
}
