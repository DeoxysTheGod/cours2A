package fr.aix.but.r404_20232024.userInterface.http.gundam;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.query.gundam.listGundamModel.ListGundamModel;
import fr.aix.but.r404_20232024.application.query.gundam.listGundamModel.ListGundamModelHandler;
import fr.aix.but.r404_20232024.application.query.kaiju.listKaijuType.ListKaijuType;
import fr.aix.but.r404_20232024.application.query.kaiju.listKaijuType.ListKaijuTypeHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/gundam")
public class ListGundamModelController {

    private ListGundamModelHandler listGundamModelHandler;

    private Gson gson;

    @Autowired
    public ListGundamModelController(ListGundamModelHandler listGundamTypeHandler) {
        this.listGundamModelHandler = listGundamTypeHandler;
        this.gson = new Gson();
    }
    
    @GetMapping("/list-model")
    public String listKaijuType() {
        return gson.toJson(listGundamModelHandler.handle(new ListGundamModel()));
    }
}
