package fr.aix.but.r404_20232024.domain.kaiju;

import fr.aix.but.r404_20232024.domain.shared.Id;

import java.util.List;

public interface KaijuRepository {
    Kaiju find(Id id);
    void save(Kaiju kaiju);

    List<Kaiju> getAllKaiju();

    void deleteKaiju(Id id);

    void deleteAllKaiju();
}
