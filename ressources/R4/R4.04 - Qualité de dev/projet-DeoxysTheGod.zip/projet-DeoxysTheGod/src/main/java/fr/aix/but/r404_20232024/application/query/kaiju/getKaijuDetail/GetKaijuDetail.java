package fr.aix.but.r404_20232024.application.query.kaiju.getKaijuDetail;

public class GetKaijuDetail {
    private String id;

    public GetKaijuDetail(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
