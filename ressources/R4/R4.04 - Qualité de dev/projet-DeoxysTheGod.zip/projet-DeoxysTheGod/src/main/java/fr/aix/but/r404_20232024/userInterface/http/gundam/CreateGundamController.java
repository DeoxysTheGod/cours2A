package fr.aix.but.r404_20232024.userInterface.http.gundam;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.command.gundam.createGundam.CreateGundam;
import fr.aix.but.r404_20232024.application.command.gundam.createGundam.CreateGundamHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/gundam")
public class CreateGundamController {
    private CreateGundamHandler createGundamHandler;
    private Gson gson;

    @Autowired
    public CreateGundamController(CreateGundamHandler createGundamHandler) {
        this.createGundamHandler = createGundamHandler;
        this.gson = new Gson();
    }

    @PostMapping(value = "/create", consumes = {"application/json"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> createGundam(@RequestBody CreateGundam createGundam) {
        return ResponseEntity.ok(gson.toJson(createGundamHandler.handle(createGundam)));
    }
}
