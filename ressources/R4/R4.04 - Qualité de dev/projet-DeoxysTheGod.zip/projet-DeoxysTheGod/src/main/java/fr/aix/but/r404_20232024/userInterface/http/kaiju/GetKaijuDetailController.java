package fr.aix.but.r404_20232024.userInterface.http.kaiju;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.query.kaiju.getKaijuDetail.GetKaijuDetail;
import fr.aix.but.r404_20232024.application.query.kaiju.getKaijuDetail.GetKaijuDetailHandler;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/kaiju")
public class GetKaijuDetailController {
    private GetKaijuDetailHandler getKaijuDetailHandler;
    private Gson gson;

    @Autowired
    public GetKaijuDetailController(GetKaijuDetailHandler getKaijuDetailHandler) {
        this.getKaijuDetailHandler = getKaijuDetailHandler;
        this.gson = new Gson();
    }

    @GetMapping("{id}/detail")
    public String getKaijuDetail(@PathVariable String id) {
        try {
            return gson.toJson(getKaijuDetailHandler.handle(new GetKaijuDetail(id)));

        } catch (NotFoundException e) {

            throw new ResponseStatusException(
                    org.springframework.http.HttpStatus.NOT_FOUND, "Kaiju not found", e);
        }
    }
}
