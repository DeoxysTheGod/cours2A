package fr.aix.but.r404_20232024.infrastructure.repository.gundam;

import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.shared.Id;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class InMemoryGundamRepository implements GundamRepository {

    Map<Id, Gundam> gundamMap;

    public InMemoryGundamRepository() {
        gundamMap = new HashMap<>();
    }

    @Override
    public void save(Gundam gundam) {
        gundamMap.put(gundam.getId(), gundam);
    }

    @Override
    public Gundam find(Id id) {
        if(gundamMap.containsKey(id)) {
            return gundamMap.get(id);
        }

        throw NotFoundException.gundamNotFound(id.getId());
    }

    @Override
    public List<Gundam> getAllGundam() {
        return gundamMap.values().stream().toList();
    }

    @Override
    public void deleteGundam(Id id) {
        gundamMap.remove(id);
    }

    @Override
    public void deleteAllGundam() {
        gundamMap.clear();
    }
}
