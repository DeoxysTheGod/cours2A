package fr.aix.but.r404_20232024.domain.battle;

import fr.aix.but.r404_20232024.domain.shared.Id;

import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BattleRepository {
    void save(Battle battle);
    Battle find(Id id);
    List<Battle> getAllBattles();
    void deleteBattle(Id id);
    void deleteAllBattles();
    void update(Battle battle);
}
