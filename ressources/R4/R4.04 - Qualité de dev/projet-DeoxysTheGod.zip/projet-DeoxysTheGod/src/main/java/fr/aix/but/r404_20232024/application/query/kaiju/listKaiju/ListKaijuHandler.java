package fr.aix.but.r404_20232024.application.query.kaiju.listKaiju;

import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ListKaijuHandler {
    KaijuRepository kaijuRepository;

    public ListKaijuHandler(KaijuRepository kaijuRepository) {
        this.kaijuRepository = kaijuRepository;
    }

    public List<KaijuReadModel> handle(ListKaiju query) {
        return kaijuRepository.getAllKaiju().stream()
                .map(Kaiju::readModel)
                .toList();
    }
}
