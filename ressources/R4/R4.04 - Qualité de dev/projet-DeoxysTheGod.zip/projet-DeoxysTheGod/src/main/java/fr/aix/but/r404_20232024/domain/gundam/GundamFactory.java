
package fr.aix.but.r404_20232024.domain.gundam;

import org.springframework.stereotype.Component;

@Component
public class GundamFactory {
    private final GundamStatsRepository gundamStatsRepository;

    public GundamFactory(GundamStatsRepository gundamStatsRepository) {
        this.gundamStatsRepository = gundamStatsRepository;
    }

    public Gundam fromType(String type, String name) {
        return switch (GundamModel.valueOf(type)) {
            case RX_78_2 -> Gundam.create(name, GundamModel.RX_78_2, gundamStatsRepository.fromType(GundamModel.RX_78_2));
            case ZAKU_II -> Gundam.create(name, GundamModel.ZAKU_II, gundamStatsRepository.fromType(GundamModel.ZAKU_II));
            case ZAKU_II_HIGH_MOBILITY -> Gundam.create(name, GundamModel.ZAKU_II_HIGH_MOBILITY, gundamStatsRepository.fromType(GundamModel.ZAKU_II_HIGH_MOBILITY));
            case GUNDAM_BARBATOS -> Gundam.create(name, GundamModel.GUNDAM_BARBATOS, gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS));
            case GUNDAM_BARBATOS_LUPUS -> Gundam.create(name, GundamModel.GUNDAM_BARBATOS_LUPUS, gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS_LUPUS));
            case GUNDAM_BARBATOS_LUPUS_REX -> Gundam.create(name, GundamModel.GUNDAM_BARBATOS_LUPUS_REX, gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS_LUPUS_REX));
            case GUNDAM_ASTRAY_RED_FRAME -> Gundam.create(name, GundamModel.GUNDAM_ASTRAY_RED_FRAME, gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_RED_FRAME));
            case GUNDAM_ASTRAY_BLUE_FRAME -> Gundam.create(name, GundamModel.GUNDAM_ASTRAY_BLUE_FRAME, gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_BLUE_FRAME));
            case GUNDAM_ASTRAY_GOLD_FRAME_AMATSU -> Gundam.create(name, GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU, gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU));
            case GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA -> Gundam.create(name, GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA, gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA));
            case GUNDAM_EXIA -> Gundam.create(name, GundamModel.GUNDAM_EXIA, gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA));
            case GUNDAM_EXIA_REPAIR -> Gundam.create(name, GundamModel.GUNDAM_EXIA_REPAIR, gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_REPAIR));
            case GUNDAM_EXIA_REPAIR_II -> Gundam.create(name, GundamModel.GUNDAM_EXIA_REPAIR_II, gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_REPAIR_II));
            case GUNDAM_EXIA_DARK_MATTER -> Gundam.create(name, GundamModel.GUNDAM_EXIA_DARK_MATTER, gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_DARK_MATTER));
            case GUNDAM_DYNAMES -> Gundam.create(name, GundamModel.GUNDAM_DYNAMES, gundamStatsRepository.fromType(GundamModel.GUNDAM_DYNAMES));
            case GUNDAM_WING_ZERO -> Gundam.create(name, GundamModel.GUNDAM_WING_ZERO, gundamStatsRepository.fromType(GundamModel.GUNDAM_WING_ZERO));
            case GUNDAM_EPYON -> Gundam.create(name, GundamModel.GUNDAM_EPYON, gundamStatsRepository.fromType(GundamModel.GUNDAM_EPYON));
            case GUNDAM_HEAVYARMS -> Gundam.create(name, GundamModel.GUNDAM_HEAVYARMS, gundamStatsRepository.fromType(GundamModel.GUNDAM_HEAVYARMS));
            case GUNDAM_SANDROCK -> Gundam.create(name, GundamModel.GUNDAM_SANDROCK, gundamStatsRepository.fromType(GundamModel.GUNDAM_SANDROCK));
            case TALLGEESE -> Gundam.create(name, GundamModel.TALLGEESE, gundamStatsRepository.fromType(GundamModel.TALLGEESE));

            default -> throw new IllegalArgumentException("Unknown type");
        };
    }
}