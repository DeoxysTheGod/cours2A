package fr.aix.but.r404_20232024.application.query.gundam.listGundam;

import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ListGundamHandler {
    GundamRepository gundamRepository;

    public ListGundamHandler(GundamRepository gundamRepository) {
        this.gundamRepository = gundamRepository;
    }

    public List<GundamReadModel> handle(ListGundam query) {
        return gundamRepository.getAllGundam().stream()
                .map(Gundam::readModel)
                .toList();
    }
}
