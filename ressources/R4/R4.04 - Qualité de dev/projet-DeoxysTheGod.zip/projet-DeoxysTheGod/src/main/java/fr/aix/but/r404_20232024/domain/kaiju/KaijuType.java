package fr.aix.but.r404_20232024.domain.kaiju;

public enum KaijuType {
    ANGUIRUS("Anguirus"),
    BARAGON("Baragon"),
    BATTRA("Battra"),
    BIOLLANTE("Biollante"),
    DESTOROYAH("Destoroyah"),
    EBIRAH("Ebirah"),
    GABARA("Gabara"),
    GANIMES("Ganimes"),
    GIGAN("Gigan"),
    GODZILLA("Godzilla"),
    GOROSAURUS("Gorosaurus"),
    GYAOS("Gyaos"),
    HEDORAH("Hedorah"),
    IRYS("Irys"),
    KAMACURAS("Kamacuras"),
    KAMOEBAS("Kamoebas"),
    KING_CAESAR("King Caesar"),
    KING_KONG("King Kong"),
    KUMONGA("Kumonga"),
    LEGION("Legion"),
    MAGUMA("Maguma"),
    MANDA("Manda"),
    MATANGO("Matango"),
    MECHAGODZILLA("Mechagodzilla"),
    MECHANI_KONG("Mechani-Kong"),
    MEGALON("Megalon"),
    MINILLA("Minilla"),
    MOGERA("Mogera"),
    MOGUERA("Moguera"),
    MOTHRA("Mothra"),
    OODAKA("Oodaka"),
    ORGA("Orga"),
    RATTLESNAKE("Rattlesnake"),
    RODAN("Rodan"),
    SPACE_GODZILLA("Space Godzilla"),
    TITANOSAURUS("Titanosaurus"),
    VARAN("Varan"),
    ZIGRA("Zigra"),
    ZILLA("Zilla"),
    ZONE_FIGHTER("Zone Fighter"),
    ;
    private final String value;

    KaijuType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
