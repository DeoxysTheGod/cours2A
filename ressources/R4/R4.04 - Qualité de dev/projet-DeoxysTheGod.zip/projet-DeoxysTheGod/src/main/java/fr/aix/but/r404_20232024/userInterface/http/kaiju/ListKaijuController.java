package fr.aix.but.r404_20232024.userInterface.http.kaiju;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.query.kaiju.listKaiju.ListKaiju;
import fr.aix.but.r404_20232024.application.query.kaiju.listKaiju.ListKaijuHandler;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/kaiju")
public class ListKaijuController {
    private ListKaijuHandler listKaijuHandler;
    private Gson gson;

    @Autowired
    public ListKaijuController(ListKaijuHandler listKaijuHandler) {
        this.listKaijuHandler = listKaijuHandler;
        this.gson = new Gson();
    }

    @GetMapping("/list")
    public String listKaiju() {
        List<KaijuReadModel> kaijuReadModels = listKaijuHandler.handle(new ListKaiju());
        return gson.toJson(kaijuReadModels);
    }
}
