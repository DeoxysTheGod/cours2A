package fr.aix.but.r404_20232024.domain.battle;

import fr.aix.but.r404_20232024.domain.battle.readModel.BattleReadModel;
import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.shared.Id;

import java.util.UUID;

public class Battle {
    private final Id id;
    private final Kaiju kaiju;
    private final Gundam gundam;
    private int turn;
    private BattleStatus status;

    private Battle(Id id, Kaiju kaiju, Gundam gundam) {
        this.id = id;
        this.kaiju = kaiju;
        this.gundam = gundam;
        this.turn = 0;
        this.status = BattleStatus.IN_PROGRESS;
    }

    protected static Battle create(Kaiju kaiju, Gundam gundam) {
        return new Battle(
                Id.generate(),
                kaiju,
                gundam
        );
    }

    public BattleReadModel readModel() {
        return new BattleReadModel(
                id.getId(),
                getKaiju(),
                getGundam(),
                getTurn(),
                getStatus().getValue()
        );
    }

    public Id getId() {
        return id;
    }

    public int getTurn() {
        return turn;
    }

    public BattleStatus getStatus() {
        return status;
    }

    public Kaiju getKaiju() {
        return kaiju;
    }

    public Gundam getGundam() {
        return gundam;
    }
}
