package fr.aix.but.r404_20232024.application.command.battle.launchTurn;

public class LaunchTurn {
    private String battleId;
}
