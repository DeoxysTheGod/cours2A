package fr.aix.but.r404_20232024.domain.battle.readModel;

import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;

public class BattleReadModel {
    private final String id;
    private final Kaiju kaiju;
    private final Gundam gundam;
    private final int turn;
    private final String status;

    public BattleReadModel(String id, Kaiju kaiju, Gundam gundam, int turn, String status) {
        this.id = id;
        this.kaiju = kaiju;
        this.gundam = gundam;
        this.turn = turn;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public Kaiju getKaiju() {
        return kaiju;
    }

    public Gundam getGundam() {
        return gundam;
    }

    public String getStatus() {
        return status;
    }

    public int getTurn() {
        return turn;
    }
}
