package fr.aix.but.r404_20232024.application.query.gundam.getGundamDetail;

import fr.aix.but.r404_20232024.application.query.gundam.getGundamDetail.GetGundamDetail;
import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import fr.aix.but.r404_20232024.domain.shared.Id;
import org.springframework.stereotype.Component;

@Component
public class GetGundamDetailHandler {
    private final GundamRepository gundamRepository;

    public GetGundamDetailHandler(GundamRepository gundamRepository) {
        this.gundamRepository = gundamRepository;
    }

    public GundamReadModel handle(GetGundamDetail getGundamDetail) {
        Gundam gundam = gundamRepository.find(Id.fromString(getGundamDetail.getId()));

        return gundam.readModel();
    }
}