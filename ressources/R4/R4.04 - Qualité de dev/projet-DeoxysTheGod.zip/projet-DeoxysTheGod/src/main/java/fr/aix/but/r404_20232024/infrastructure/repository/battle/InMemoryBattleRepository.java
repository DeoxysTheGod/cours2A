package fr.aix.but.r404_20232024.infrastructure.repository.battle;

import fr.aix.but.r404_20232024.domain.battle.Battle;
import fr.aix.but.r404_20232024.domain.battle.BattleRepository;
import fr.aix.but.r404_20232024.domain.shared.Id;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class InMemoryBattleRepository implements BattleRepository {
    Map<Id, Battle> battleMap;

    public InMemoryBattleRepository() {
        battleMap = new HashMap<>();
    }

    @Override
    public void save(Battle battle) {
        battleMap.put(battle.getId(), battle);
    }

    @Override
    public Battle find(Id id) {
        return battleMap.get(id);
    }

    @Override
    public List<Battle> getAllBattles() {
        return battleMap.values().stream().toList();
    }

    @Override
    public void deleteBattle(Id id) {
        battleMap.remove(id);
    }

    @Override
    public void deleteAllBattles() {
        battleMap.clear();
    }

    @Override
    public void update(Battle battle) {
        //battleMap.put(battle.getId(), battle);
    }
}
