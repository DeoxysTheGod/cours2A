package fr.aix.but.r404_20232024.application.query.kaiju.listKaijuType;

public class ListKaijuType {
}
