package fr.aix.but.r404_20232024.domain.battle;

import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import org.springframework.stereotype.Component;

@Component
public class BattleFactory {

    public Battle createBattle(Kaiju kaiju, Gundam gundam) {
        return Battle.create(kaiju, gundam);
    }
}
