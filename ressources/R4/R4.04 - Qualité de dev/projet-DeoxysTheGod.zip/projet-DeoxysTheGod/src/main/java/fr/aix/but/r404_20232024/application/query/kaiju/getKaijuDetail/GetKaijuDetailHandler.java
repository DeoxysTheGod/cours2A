package fr.aix.but.r404_20232024.application.query.kaiju.getKaijuDetail;

import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import fr.aix.but.r404_20232024.domain.shared.Id;
import org.springframework.stereotype.Component;

@Component
public class GetKaijuDetailHandler {
    private final KaijuRepository kaijuRepository;

    public GetKaijuDetailHandler(KaijuRepository kaijuRepository) {
        this.kaijuRepository = kaijuRepository;
    }

    public KaijuReadModel handle(GetKaijuDetail getKaijuDetail) {
        Kaiju kaiju = kaijuRepository.getKaijuById(Id.fromString(getKaijuDetail.getId()));

        return kaiju.readModel();
    }
}
