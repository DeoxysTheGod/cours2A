package fr.aix.but.r404_20232024.infrastructure.repository.kaiju;

import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.shared.Id;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class InMemoryKaijuRepository implements KaijuRepository {

    Map<Id, Kaiju> kaijuMap;

    public InMemoryKaijuRepository() {
        kaijuMap = new HashMap<>();
    }

    @Override
    public Kaiju find(Id id) {
        if (kaijuMap.containsKey(id)) {
            return kaijuMap.get(id);
        }
        throw NotFoundException.kaijuNotFound(id.getId());
    }

    @Override
    public void save(Kaiju kaiju) {
        kaijuMap.put(kaiju.getId(), kaiju);
    }

    @Override
    public List<Kaiju> getAllKaiju() {
        return kaijuMap.values().stream().toList();
    }

    @Override
    public void deleteKaiju(Id id) {
        kaijuMap.remove(id);
    }

    @Override
    public void deleteAllKaiju() {
        kaijuMap.clear();
    }
}
