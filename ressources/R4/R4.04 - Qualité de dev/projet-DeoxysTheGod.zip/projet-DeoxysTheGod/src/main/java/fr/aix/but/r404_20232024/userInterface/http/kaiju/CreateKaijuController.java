package fr.aix.but.r404_20232024.userInterface.http.kaiju;

import com.google.gson.Gson;
import fr.aix.but.r404_20232024.application.command.kaiju.createKaiju.CreateKaiju;
import fr.aix.but.r404_20232024.application.command.kaiju.createKaiju.CreateKaijuHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/kaiju")
public class CreateKaijuController
{
    private CreateKaijuHandler createKaijuHandler;
    private Gson gson;

    @Autowired
    public CreateKaijuController(CreateKaijuHandler createKaijuHandler) {
        this.createKaijuHandler = createKaijuHandler;
        this.gson = new Gson();
    }

    @PostMapping(value = "/create", consumes = {"application/json"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> createKaiju(@RequestBody CreateKaiju createKaiju) {
        return ResponseEntity.ok(gson.toJson(createKaijuHandler.handle(createKaiju)));
    }
}
