package fr.aix.but.r404_20232024.domain.kaiju;

import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import fr.aix.but.r404_20232024.domain.shared.Character;
import fr.aix.but.r404_20232024.domain.shared.Id;

public class Kaiju implements Character {
    private final Id id;
    private final String name;

    private final int maxHealth;
    private final KaijuType type;
    private int currentHealth;

    private final int attack;

    private final int defense;

    private final int speed;

    private final int criticalChance;

    private final int evadeChance;

    private final int accuracy;

    private Kaiju(Id id, String name, KaijuType type, int maxHealth, int attack, int defense, int speed, int criticalChance, int evadeChance, int accuracy) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.maxHealth = maxHealth;
        this.currentHealth = maxHealth;
        this.attack = attack;
        this.defense = defense;
        this.speed = speed;
        this.criticalChance = criticalChance;
        this.evadeChance = evadeChance;
        this.accuracy = accuracy;
    }

    protected static Kaiju create(String name, KaijuType type, KaijuStats stats) {
        return new Kaiju(
            Id.generate(),
            name,
            type,
            stats.maxHealth(),
            stats.attack(),
            stats.defense(),
            stats.speed(),
            stats.criticalChance(),
            stats.evadeChance(),
            stats.accuracy()
        );
    }


    public KaijuReadModel readModel() {
        return new KaijuReadModel(
            id.getId(),
            name,
            getType().getValue(),
            getMaxHealth(),
            getHealth(),
            getAttack(),
            getDefense(),
            getSpeed(),
            getCriticalChance(),
            getEvadeChance(),
            getAccuracy()
        );
    }

    public Id getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public int getHealth() {
        return currentHealth;
    }

    @Override
    public int getMaxHealth() {
        return maxHealth;
    }

    @Override
    public int getAttack() {
        return attack;
    }

    @Override
    public int getDefense() {
        return Math.max(defense, 0);
    }

    @Override
    public int getSpeed() {
        return speed;
    }

    @Override
    public int getCriticalChance() {
        return criticalChance;
    }

    @Override
    public int getEvadeChance() {
        return evadeChance;
    }

    @Override
    public int getAccuracy() {
        return accuracy / 2;
    }

    public int takeDamage(int damage) {
        int damageTaken = (damage - getDefense()) / 2;

        if (damageTaken < 0) {
            damageTaken = 0;
        }

        currentHealth -= damageTaken;

        return damageTaken;
    }

    public KaijuType getType() {
        return type;
    }
}
