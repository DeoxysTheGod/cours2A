package fr.aix.but.r404_20232024.domain.kaiju;

import org.springframework.stereotype.Component;

@Component
public class KaijuStatsRepository {
    public KaijuStats fromType(KaijuType type) {
        return switch (type) {
            case ANGUIRUS -> new KaijuStats(170, 76, 39, 8, 98, 9, 15);
            case BARAGON -> new KaijuStats(266, 54, 81, 24, 29, 38, 97);
            case BATTRA -> new KaijuStats(758, 22, 44, 48, 1, 13, 75);
            case BIOLLANTE -> new KaijuStats(723, 25, 18, 66, 24, 22, 44);
            case DESTOROYAH -> new KaijuStats(235, 95, 8, 48, 78, 76, 89);
            case EBIRAH -> new KaijuStats(795, 84, 99, 24, 92, 2, 53);
            case GABARA -> new KaijuStats(550, 75, 61, 89, 64, 89, 55);
            case GANIMES -> new KaijuStats(622, 99, 86, 89, 2, 17, 96);
            case GIGAN -> new KaijuStats(122, 89, 32, 50, 9, 43, 89);
            case GODZILLA -> new KaijuStats(884, 58, 11, 7, 84, 36, 10);
            case GOROSAURUS -> new KaijuStats(249, 57, 61, 6, 96, 83, 78);
            case GYAOS -> new KaijuStats(807, 19, 12, 97, 56, 51, 32);
            case HEDORAH -> new KaijuStats(430, 79, 25, 88, 57, 87, 40);
            case IRYS -> new KaijuStats(801, 20, 68, 52, 68, 45, 15);
            case KAMACURAS -> new KaijuStats(480, 5, 45, 35, 45, 24, 66);
            case KAMOEBAS -> new KaijuStats(615, 42, 7, 81, 43, 68, 14);
            case KING_CAESAR -> new KaijuStats(457, 61, 69, 62, 48, 45, 78);
            case KING_KONG -> new KaijuStats(939, 64, 12, 23, 43, 79, 95);
            case KUMONGA -> new KaijuStats(627, 31, 65, 64, 89, 28, 10);
            case LEGION -> new KaijuStats(700, 5, 61, 40, 1, 48, 9);
            case MAGUMA -> new KaijuStats(223, 24, 8, 72, 64, 59, 29);
            case MANDA -> new KaijuStats(760, 51, 10, 38, 77, 50, 89);
            case MATANGO -> new KaijuStats(966, 52, 7, 25, 50, 75, 90);
            case MECHAGODZILLA -> new KaijuStats(780, 39, 72, 38, 29, 56, 7);
            case MECHANI_KONG -> new KaijuStats(769, 37, 80, 17, 86, 58, 61);
            case MEGALON -> new KaijuStats(402, 74, 8, 22, 81, 5, 82);
            case MINILLA -> new KaijuStats(388, 42, 42, 46, 26, 9, 1);
            case MOGERA -> new KaijuStats(574, 46, 30, 27, 49, 14, 69);
            case MOGUERA -> new KaijuStats(726, 75, 70, 16, 13, 62, 29);
            case MOTHRA -> new KaijuStats(960, 90, 39, 40, 23, 80, 83);
            case OODAKA -> new KaijuStats(943, 94, 98, 92, 99, 77, 32);
            case ORGA -> new KaijuStats(266, 52, 90, 77, 50, 82, 95);
            case RATTLESNAKE -> new KaijuStats(244, 56, 72, 18, 73, 58, 85);
            case RODAN -> new KaijuStats(154, 43, 35, 21, 25, 41, 12);
            case SPACE_GODZILLA -> new KaijuStats(579, 31, 13, 59, 2, 80, 70);
            case TITANOSAURUS -> new KaijuStats(778, 88, 47, 42, 82, 34, 86);
            case VARAN -> new KaijuStats(893, 31, 6, 71, 44, 3, 73);
            case ZIGRA -> new KaijuStats(768, 55, 94, 27, 54, 22, 11);
            case ZILLA -> new KaijuStats(819, 56, 31, 48, 70, 14, 7);
            case ZONE_FIGHTER -> new KaijuStats(548, 51, 46, 48, 66, 23, 3);

            default -> throw new IllegalArgumentException("Unknown type");
        };
    }
}
