package fr.aix.but.r404_20232024.application.command.kaiju.createKaiju;

import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuFactory;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CreateKaijuHandler {

    KaijuRepository kaijuRepository;
    KaijuFactory kaijuFactory;

    public CreateKaijuHandler(KaijuRepository kaijuRepository, KaijuFactory kaijuFactory) {
        this.kaijuRepository = kaijuRepository;
        this.kaijuFactory = kaijuFactory;
    }

    public KaijuReadModel handle(CreateKaiju createKaiju) {
        Kaiju kaiju = kaijuFactory.fromType(createKaiju.getType(), createKaiju.getName());

        kaijuRepository.save(kaiju);
        return kaiju.readModel();
    }
}
