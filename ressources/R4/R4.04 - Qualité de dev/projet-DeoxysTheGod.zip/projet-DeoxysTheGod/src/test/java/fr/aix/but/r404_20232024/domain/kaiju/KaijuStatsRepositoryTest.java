package fr.aix.but.r404_20232024.domain.kaiju;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class KaijuStatsRepositoryTest {
    KaijuStatsRepository kaijuStatsRepository;
    @BeforeEach
    void setUp() {
        kaijuStatsRepository = new KaijuStatsRepository();
    }

    @Test
    void fromAnguirusType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.ANGUIRUS);
        assertEquals(170, stats.maxHealth());
        assertEquals(76, stats.attack());
        assertEquals(39, stats.defense());
        assertEquals(8, stats.speed());
        assertEquals(98, stats.criticalChance());
        assertEquals(9, stats.evadeChance());
        assertEquals(15, stats.accuracy());
    }

    @Test
    void fromBaragonType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.BARAGON);
        assertEquals(266, stats.maxHealth());
        assertEquals(54, stats.attack());
        assertEquals(81, stats.defense());
        assertEquals(24, stats.speed());
        assertEquals(29, stats.criticalChance());
        assertEquals(38, stats.evadeChance());
        assertEquals(97, stats.accuracy());
    }

    @Test
    void fromBattraType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.BATTRA);
        assertEquals(758, stats.maxHealth());
        assertEquals(22, stats.attack());
        assertEquals(44, stats.defense());
        assertEquals(48, stats.speed());
        assertEquals(1, stats.criticalChance());
        assertEquals(13, stats.evadeChance());
        assertEquals(75, stats.accuracy());
    }

    @Test
    void fromBiollanteType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.BIOLLANTE);
        assertEquals(723, stats.maxHealth());
        assertEquals(25, stats.attack());
        assertEquals(18, stats.defense());
        assertEquals(66, stats.speed());
        assertEquals(24, stats.criticalChance());
        assertEquals(22, stats.evadeChance());
        assertEquals(44, stats.accuracy());
    }

    @Test
    void fromDestoroyahType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.DESTOROYAH);
        assertEquals(235, stats.maxHealth());
        assertEquals(95, stats.attack());
        assertEquals(8, stats.defense());
        assertEquals(48, stats.speed());
        assertEquals(78, stats.criticalChance());
        assertEquals(76, stats.evadeChance());
        assertEquals(89, stats.accuracy());
    }

    @Test
    void fromEbirahType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.EBIRAH);
        assertEquals(795, stats.maxHealth());
        assertEquals(84, stats.attack());
        assertEquals(99, stats.defense());
        assertEquals(24, stats.speed());
        assertEquals(92, stats.criticalChance());
        assertEquals(2, stats.evadeChance());
        assertEquals(53, stats.accuracy());
    }

    @Test
    void fromGabaraType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.GABARA);
        assertEquals(550, stats.maxHealth());
        assertEquals(75, stats.attack());
        assertEquals(61, stats.defense());
        assertEquals(89, stats.speed());
        assertEquals(64, stats.criticalChance());
        assertEquals(89, stats.evadeChance());
        assertEquals(55, stats.accuracy());
    }

    @Test
    void fromGanimesType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.GANIMES);
        assertEquals(622, stats.maxHealth());
        assertEquals(99, stats.attack());
        assertEquals(86, stats.defense());
        assertEquals(89, stats.speed());
        assertEquals(2, stats.criticalChance());
        assertEquals(17, stats.evadeChance());
        assertEquals(96, stats.accuracy());
    }

    @Test
    void fromGiganType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.GIGAN);
        assertEquals(122, stats.maxHealth());
        assertEquals(89, stats.attack());
        assertEquals(32, stats.defense());
        assertEquals(50, stats.speed());
        assertEquals(9, stats.criticalChance());
        assertEquals(43, stats.evadeChance());
        assertEquals(89, stats.accuracy());
    }

    @Test
    void fromGodzillaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.GODZILLA);
        assertEquals(884, stats.maxHealth());
        assertEquals(58, stats.attack());
        assertEquals(11, stats.defense());
        assertEquals(7, stats.speed());
        assertEquals(84, stats.criticalChance());
        assertEquals(36, stats.evadeChance());
        assertEquals(10, stats.accuracy());
    }

    @Test
    void fromGorosaurusType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.GOROSAURUS);
        assertEquals(249, stats.maxHealth());
        assertEquals(57, stats.attack());
        assertEquals(61, stats.defense());
        assertEquals(6, stats.speed());
        assertEquals(96, stats.criticalChance());
        assertEquals(83, stats.evadeChance());
        assertEquals(78, stats.accuracy());
    }

    @Test
    void fromGyaosType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.GYAOS);
        assertEquals(807, stats.maxHealth());
        assertEquals(19, stats.attack());
        assertEquals(12, stats.defense());
        assertEquals(97, stats.speed());
        assertEquals(56, stats.criticalChance());
        assertEquals(51, stats.evadeChance());
        assertEquals(32, stats.accuracy());
    }

    @Test
    void fromHedorahType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.HEDORAH);
        assertEquals(430, stats.maxHealth());
        assertEquals(79, stats.attack());
        assertEquals(25, stats.defense());
        assertEquals(88, stats.speed());
        assertEquals(57, stats.criticalChance());
        assertEquals(87, stats.evadeChance());
        assertEquals(40, stats.accuracy());
    }

    @Test
    void fromIrysType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.IRYS);
        assertEquals(801, stats.maxHealth());
        assertEquals(20, stats.attack());
        assertEquals(68, stats.defense());
        assertEquals(52, stats.speed());
        assertEquals(68, stats.criticalChance());
        assertEquals(45, stats.evadeChance());
        assertEquals(15, stats.accuracy());
    }

    @Test
    void fromKamacurasType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.KAMACURAS);
        assertEquals(480, stats.maxHealth());
        assertEquals(5, stats.attack());
        assertEquals(45, stats.defense());
        assertEquals(35, stats.speed());
        assertEquals(45, stats.criticalChance());
        assertEquals(24, stats.evadeChance());
        assertEquals(66, stats.accuracy());
    }

    @Test
    void fromKamoebasType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.KAMOEBAS);
        assertEquals(615, stats.maxHealth());
        assertEquals(42, stats.attack());
        assertEquals(7, stats.defense());
        assertEquals(81, stats.speed());
        assertEquals(43, stats.criticalChance());
        assertEquals(68, stats.evadeChance());
        assertEquals(14, stats.accuracy());
    }

    @Test
    void fromKingCaesarType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.KING_CAESAR);
        assertEquals(457, stats.maxHealth());
        assertEquals(61, stats.attack());
        assertEquals(69, stats.defense());
        assertEquals(62, stats.speed());
        assertEquals(48, stats.criticalChance());
        assertEquals(45, stats.evadeChance());
        assertEquals(78, stats.accuracy());
    }

    @Test
    void fromKingKongType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.KING_KONG);
        assertEquals(939, stats.maxHealth());
        assertEquals(64, stats.attack());
        assertEquals(12, stats.defense());
        assertEquals(23, stats.speed());
        assertEquals(43, stats.criticalChance());
        assertEquals(79, stats.evadeChance());
        assertEquals(95, stats.accuracy());
    }

    @Test
    void fromKumongaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.KUMONGA);
        assertEquals(627, stats.maxHealth());
        assertEquals(31, stats.attack());
        assertEquals(65, stats.defense());
        assertEquals(64, stats.speed());
        assertEquals(89, stats.criticalChance());
        assertEquals(28, stats.evadeChance());
        assertEquals(10, stats.accuracy());
    }

    @Test
    void fromLegionType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.LEGION);
        assertEquals(700, stats.maxHealth());
        assertEquals(5, stats.attack());
        assertEquals(61, stats.defense());
        assertEquals(40, stats.speed());
        assertEquals(1, stats.criticalChance());
        assertEquals(48, stats.evadeChance());
        assertEquals(9, stats.accuracy());
    }

    @Test
    void fromMagumaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MAGUMA);
        assertEquals(223, stats.maxHealth());
        assertEquals(24, stats.attack());
        assertEquals(8, stats.defense());
        assertEquals(72, stats.speed());
        assertEquals(64, stats.criticalChance());
        assertEquals(59, stats.evadeChance());
        assertEquals(29, stats.accuracy());
    }

    @Test
    void fromMandaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MANDA);
        assertEquals(760, stats.maxHealth());
        assertEquals(51, stats.attack());
        assertEquals(10, stats.defense());
        assertEquals(38, stats.speed());
        assertEquals(77, stats.criticalChance());
        assertEquals(50, stats.evadeChance());
        assertEquals(89, stats.accuracy());
    }

    @Test
    void fromMatangoType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MATANGO);
        assertEquals(966, stats.maxHealth());
        assertEquals(52, stats.attack());
        assertEquals(7, stats.defense());
        assertEquals(25, stats.speed());
        assertEquals(50, stats.criticalChance());
        assertEquals(75, stats.evadeChance());
        assertEquals(90, stats.accuracy());
    }

    @Test
    void fromMechagodzillaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MECHAGODZILLA);
        assertEquals(780, stats.maxHealth());
        assertEquals(39, stats.attack());
        assertEquals(72, stats.defense());
        assertEquals(38, stats.speed());
        assertEquals(29, stats.criticalChance());
        assertEquals(56, stats.evadeChance());
        assertEquals(7, stats.accuracy());
    }

    @Test
    void fromMechaniKongType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MECHANI_KONG);
        assertEquals(769, stats.maxHealth());
        assertEquals(37, stats.attack());
        assertEquals(80, stats.defense());
        assertEquals(17, stats.speed());
        assertEquals(86, stats.criticalChance());
        assertEquals(58, stats.evadeChance());
        assertEquals(61, stats.accuracy());
    }

    @Test
    void fromMegalonType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MEGALON);
        assertEquals(402, stats.maxHealth());
        assertEquals(74, stats.attack());
        assertEquals(8, stats.defense());
        assertEquals(22, stats.speed());
        assertEquals(81, stats.criticalChance());
        assertEquals(5, stats.evadeChance());
        assertEquals(82, stats.accuracy());
    }

    @Test
    void fromMinillaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MINILLA);
        assertEquals(388, stats.maxHealth());
        assertEquals(42, stats.attack());
        assertEquals(42, stats.defense());
        assertEquals(46, stats.speed());
        assertEquals(26, stats.criticalChance());
        assertEquals(9, stats.evadeChance());
        assertEquals(1, stats.accuracy());
    }

    @Test
    void fromMogeraType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MOGERA);
        assertEquals(574, stats.maxHealth());
        assertEquals(46, stats.attack());
        assertEquals(30, stats.defense());
        assertEquals(27, stats.speed());
        assertEquals(49, stats.criticalChance());
        assertEquals(14, stats.evadeChance());
        assertEquals(69, stats.accuracy());
    }

    @Test
    void fromMogueraType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MOGUERA);
        assertEquals(726, stats.maxHealth());
        assertEquals(75, stats.attack());
        assertEquals(70, stats.defense());
        assertEquals(16, stats.speed());
        assertEquals(13, stats.criticalChance());
        assertEquals(62, stats.evadeChance());
        assertEquals(29, stats.accuracy());
    }

    @Test
    void fromMothraType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.MOTHRA);
        assertEquals(960, stats.maxHealth());
        assertEquals(90, stats.attack());
        assertEquals(39, stats.defense());
        assertEquals(40, stats.speed());
        assertEquals(23, stats.criticalChance());
        assertEquals(80, stats.evadeChance());
        assertEquals(83, stats.accuracy());
    }

    @Test
    void fromOodakaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.OODAKA);
        assertEquals(943, stats.maxHealth());
        assertEquals(94, stats.attack());
        assertEquals(98, stats.defense());
        assertEquals(92, stats.speed());
        assertEquals(99, stats.criticalChance());
        assertEquals(77, stats.evadeChance());
        assertEquals(32, stats.accuracy());
    }

    @Test
    void fromOrgaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.ORGA);
        assertEquals(266, stats.maxHealth());
        assertEquals(52, stats.attack());
        assertEquals(90, stats.defense());
        assertEquals(77, stats.speed());
        assertEquals(50, stats.criticalChance());
        assertEquals(82, stats.evadeChance());
        assertEquals(95, stats.accuracy());
    }

    @Test
    void fromRattlesnakeType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.RATTLESNAKE);
        assertEquals(244, stats.maxHealth());
        assertEquals(56, stats.attack());
        assertEquals(72, stats.defense());
        assertEquals(18, stats.speed());
        assertEquals(73, stats.criticalChance());
        assertEquals(58, stats.evadeChance());
        assertEquals(85, stats.accuracy());
    }

    @Test
    void fromRodanType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.RODAN);
        assertEquals(154, stats.maxHealth());
        assertEquals(43, stats.attack());
        assertEquals(35, stats.defense());
        assertEquals(21, stats.speed());
        assertEquals(25, stats.criticalChance());
        assertEquals(41, stats.evadeChance());
        assertEquals(12, stats.accuracy());
    }

    @Test
    void fromSpaceGodzillaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.SPACE_GODZILLA);
        assertEquals(579, stats.maxHealth());
        assertEquals(31, stats.attack());
        assertEquals(13, stats.defense());
        assertEquals(59, stats.speed());
        assertEquals(2, stats.criticalChance());
        assertEquals(80, stats.evadeChance());
        assertEquals(70, stats.accuracy());
    }

    @Test
    void fromTitanosaurusType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.TITANOSAURUS);
        assertEquals(778, stats.maxHealth());
        assertEquals(88, stats.attack());
        assertEquals(47, stats.defense());
        assertEquals(42, stats.speed());
        assertEquals(82, stats.criticalChance());
        assertEquals(34, stats.evadeChance());
        assertEquals(86, stats.accuracy());
    }

    @Test
    void fromVaranType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.VARAN);
        assertEquals(893, stats.maxHealth());
        assertEquals(31, stats.attack());
        assertEquals(6, stats.defense());
        assertEquals(71, stats.speed());
        assertEquals(44, stats.criticalChance());
        assertEquals(3, stats.evadeChance());
        assertEquals(73, stats.accuracy());
    }

    @Test
    void fromZigraType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.ZIGRA);
        assertEquals(768, stats.maxHealth());
        assertEquals(55, stats.attack());
        assertEquals(94, stats.defense());
        assertEquals(27, stats.speed());
        assertEquals(54, stats.criticalChance());
        assertEquals(22, stats.evadeChance());
        assertEquals(11, stats.accuracy());
    }

    @Test
    void fromZillaType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.ZILLA);
        assertEquals(819, stats.maxHealth());
        assertEquals(56, stats.attack());
        assertEquals(31, stats.defense());
        assertEquals(48, stats.speed());
        assertEquals(70, stats.criticalChance());
        assertEquals(14, stats.evadeChance());
        assertEquals(7, stats.accuracy());
    }

    @Test
    void fromZoneFighterType() {
        KaijuStats stats = kaijuStatsRepository.fromType(KaijuType.ZONE_FIGHTER);
        assertEquals(548, stats.maxHealth());
        assertEquals(51, stats.attack());
        assertEquals(46, stats.defense());
        assertEquals(48, stats.speed());
        assertEquals(66, stats.criticalChance());
        assertEquals(23, stats.evadeChance());
        assertEquals(3, stats.accuracy());
    }

}