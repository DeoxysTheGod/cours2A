package fr.aix.but.r404_20232024.infrastructure.repository.kaiju;

import fr.aix.but.r404_20232024.domain.kaiju.Kaiju;
import fr.aix.but.r404_20232024.domain.shared.Id;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class InMemoryKaijuRepositoryTest {

    Kaiju kaiju;
    Id id;
    InMemoryKaijuRepository inMemoryKaijuRepository;
    @BeforeEach
    void setUp() {
        kaiju = mock();
        id = mock();
        when(id.getId()).thenReturn("id");
        when(kaiju.getId()).thenReturn(id);
        inMemoryKaijuRepository = new InMemoryKaijuRepository();
    }

    @Test
    void testEmpty() {
        assertTrue(inMemoryKaijuRepository.getAllKaiju().isEmpty());
    }

    @Test
    void testSave() {
        assertTrue(inMemoryKaijuRepository.getAllKaiju().isEmpty());
        inMemoryKaijuRepository.save(kaiju);
        assertFalse(inMemoryKaijuRepository.getAllKaiju().isEmpty());
    }

    @Test
    void testGetKaijuByIdWhenKaijuExists() {
        inMemoryKaijuRepository.save(kaiju);
        assertEquals(kaiju, inMemoryKaijuRepository.getKaijuById(id));
    }

    @Test
    void testGetKaijuByIdWhenKaijuDoesNotExist() {
        assertThrows(NotFoundException.class, () -> inMemoryKaijuRepository.getKaijuById(id));
    }

    @Test
    void testGetKaijuByIdWhenAnotherKaijuExists() {
        Kaiju kaiju2 = mock();
        Id id2 = mock();
        when(id2.getId()).thenReturn("id2");
        when(kaiju2.getId()).thenReturn(id2);
        inMemoryKaijuRepository.save(kaiju);
        inMemoryKaijuRepository.save(kaiju2);
        assertEquals(kaiju2, inMemoryKaijuRepository.getKaijuById(id2));
    }

    @Test
    void testGetKaijuByIdWhenAnotherKaijuDoesNotExist() {
        Kaiju kaiju2 = mock();
        Id id2 = mock();
        when(id2.getId()).thenReturn("id2");
        when(kaiju2.getId()).thenReturn(id2);
        inMemoryKaijuRepository.save(kaiju);
        assertThrows(NotFoundException.class, () -> inMemoryKaijuRepository.getKaijuById(id2));
    }

}