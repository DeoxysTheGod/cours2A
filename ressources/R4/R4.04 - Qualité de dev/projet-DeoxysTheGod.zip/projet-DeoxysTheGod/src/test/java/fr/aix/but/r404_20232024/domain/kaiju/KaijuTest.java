package fr.aix.but.r404_20232024.domain.kaiju;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class KaijuTest {

    KaijuStats stats;
    Kaiju kaiju;

    @BeforeEach
    void setUp() {
        stats = new KaijuStats(1, 2, 3, 4, 5, 6, 7);
        kaiju = Kaiju.create("name", KaijuType.ANGUIRUS, stats);
    }

    @Test
    void create() {
        assertNotNull(kaiju);
    }

    @Test
    void readModel() {
        assertNotNull(kaiju.readModel());
    }

    @Test
    void getId() {
        assertNotNull(kaiju.getId().getId());
        UUID parsed = UUID.fromString(kaiju.getId().getId());
        assertEquals(kaiju.getId().getId(), parsed.toString());
    }

    @Test
    void getName() {
        assertEquals("name", kaiju.getName());
    }

    @Test
    void getHealth() {
        assertEquals(1, kaiju.getHealth());
    }

    @Test
    void getMaxHealth() {
        assertEquals(1, kaiju.getMaxHealth());
    }

    @Test
    void getAttack() {
        assertEquals(2, kaiju.getAttack());
    }

    @Test
    void getDefense() {
        assertEquals(3, kaiju.getDefense());
    }

    @Test
    void getSpeed() {
        assertEquals(4, kaiju.getSpeed());
    }

    @Test
    void getCriticalChance() {
        assertEquals(5, kaiju.getCriticalChance());
    }

    @Test
    void getEvadeChance() {
        assertEquals(6, kaiju.getEvadeChance());
    }

    @Test
    void getAccuracy() {
        assertEquals(7/2, kaiju.getAccuracy());
    }

    @Test
    void takeDamage() {
        assertEquals(0, kaiju.takeDamage(1));

        assertEquals(0, kaiju.takeDamage(2));

        // 5 - 3 = 2 / 2 = 1
        assertEquals(1, kaiju.takeDamage(5));

        // 6 - 3 = 3 / 2 = 1
        assertEquals(1, kaiju.takeDamage(6));
    }

    @Test
    void takeDamageWithNegativeDamage() {
        assertEquals(0, kaiju.takeDamage(-1));
    }

    @Test
    void takeDamageWithNegativeHealthAndNegativeDefenseAndNegativeDamage() {
        stats = new KaijuStats(-1, 2, -3, 4, 5, 6, 7);
        kaiju = Kaiju.create("name", KaijuType.ANGUIRUS, stats);

        assertEquals(0, kaiju.takeDamage(-5));
    }

    @Test
    void takeDamageWithNegativeHealthAndNegativeDamage() {
        stats = new KaijuStats(-1, 2, 3, 4, 5, 6, 7);
        kaiju = Kaiju.create("name", KaijuType.ANGUIRUS, stats);

        assertEquals(0, kaiju.takeDamage(-5));
    }


    @Test
    void getKaijuType() {
        assertEquals(KaijuType.ANGUIRUS, kaiju.getType());
    }

    @Test
    void takeDamageWithNegativeDefense() {
        stats = new KaijuStats(10, 2, -3, 4, 5, 6, 7);
        kaiju = Kaiju.create("name", KaijuType.ANGUIRUS, stats);

        // (5 - 0) / 2 = 2
        assertEquals(2, kaiju.takeDamage(5));
    }
}