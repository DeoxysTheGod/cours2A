package fr.aix.but.r404_20232024;

import fr.aix.but.r404_20232024.SpringIntegrationTest;
import fr.aix.but.r404_20232024.application.command.kaiju.createKaiju.CreateKaiju;
import fr.aix.but.r404_20232024.application.command.kaiju.createKaiju.CreateKaijuHandler;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class KaijuStepsDefinition extends SpringIntegrationTest {

    CreateKaijuHandler createKaijuHandler;
    private KaijuReadModel kaijuReadModel;

    @Autowired
    public KaijuStepsDefinition(CreateKaijuHandler createKaijuHandler) {
        this.createKaijuHandler = createKaijuHandler;
    }

    @Autowired
    public KaijuRepository kaijuRepository;

    @Before
    public void clearKaiju() {
        kaijuRepository.deleteAllKaiju();
    }

    // Create Kaiju
    @When("I create a Kaiju with its name and species")
    public void iCreateAKaijuWithItsNameAndSpecies(DataTable table) throws JSONException, IOException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String name = rows.get(0).get("name");
        String species = rows.get(0).get("species");

        createKaiju(name, species);
    }

    private void createKaiju(String name, String species) throws JSONException, IOException {
        JSONObject body = new JSONObject();
        body.put("name", name);
        body.put("type", species);

        executePost("/kaiju/create", body);
    }

    @Given("A Kaiju was created")
    public void aKaijuWasCreated() throws JSONException, IOException {
        kaijuReadModel = createKaijuHandler.handle(new CreateKaiju("Godzilla-chan", "GODZILLA"));
    }

    @Then("I should see a Kaiju with its name and species")
    public void iShouldSeeAKaijuWithItsNameAndSpecies(DataTable table) throws IOException, JSONException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String name = rows.get(0).get("name");
        String species = rows.get(0).get("species");

        JSONObject body = new JSONObject(latestResponse.getBody());
        System.out.println(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(name, body.getString("name"));
        Assert.assertEquals(species, body.getString("type"));
    }

    // List Kaiju
    @When("I list Kaiju")
    public void iListKaiju() throws IOException, JSONException {
        executeGet("/kaiju/list");
    }

    @Then("I should have {int} Kaiju")
    public void iShouldHaveKaiju(int count) throws JSONException, IOException {

        JSONArray body = new JSONArray(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(count, body.length());
    }

    // Kaiju details
    @When("I detail Kaiju")
    public void iDetailKaiju() throws IOException {
        executeGet("/kaiju/" + kaijuReadModel.getId() + "/detail");
    }

    @When("I list Kaiju type")
    public void iListKaijuType() throws IOException {
        executeGet("/kaiju/list-type");
    }

    @Then("I should have {int} Kaiju type")
    public void iShouldHaveKaijuType(int count) throws JSONException, IOException {
        JSONArray body = new JSONArray(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(count, body.length());
    }
}
