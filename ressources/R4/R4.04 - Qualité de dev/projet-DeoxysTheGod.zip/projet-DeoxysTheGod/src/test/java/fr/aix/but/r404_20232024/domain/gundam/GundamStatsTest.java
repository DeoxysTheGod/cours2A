package fr.aix.but.r404_20232024.domain.gundam;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GundamStatsTest {
    @Test
    void testConstructor() {
        GundamStats actualGundamStats = new GundamStats(1, 2, 3, 4, 5, 6, 7);
        assertEquals(1, actualGundamStats.maxHealth());
        assertEquals(2, actualGundamStats.attack());
        assertEquals(3, actualGundamStats.defense());
        assertEquals(4, actualGundamStats.speed());
        assertEquals(5, actualGundamStats.criticalChance());
        assertEquals(6, actualGundamStats.evadeChance());
        assertEquals(7, actualGundamStats.accuracy());
    }
}
