package fr.aix.but.r404_20232024;

import fr.aix.but.r404_20232024.application.command.battle.createBattle.CreateBattleHandler;
import fr.aix.but.r404_20232024.application.command.gundam.createGundam.CreateGundam;
import fr.aix.but.r404_20232024.application.command.gundam.createGundam.CreateGundamHandler;
import fr.aix.but.r404_20232024.application.command.kaiju.createKaiju.CreateKaiju;
import fr.aix.but.r404_20232024.application.command.kaiju.createKaiju.CreateKaijuHandler;
import fr.aix.but.r404_20232024.domain.battle.BattleRepository;
import fr.aix.but.r404_20232024.domain.battle.readModel.BattleReadModel;
import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import fr.aix.but.r404_20232024.domain.kaiju.KaijuRepository;
import fr.aix.but.r404_20232024.domain.kaiju.readModel.KaijuReadModel;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class BattleStepsDefinition extends SpringIntegrationTest {

    CreateGundamHandler createGundamHandler;
    private GundamReadModel gundamReadModel;

    CreateKaijuHandler createKaijuHandler;
    private KaijuReadModel kaijuReadModel;

    CreateBattleHandler createBattleHandler;
    private BattleReadModel battleReadModel;

    @Autowired
    public BattleStepsDefinition(CreateGundamHandler createGundamHandler, CreateKaijuHandler createKaijuHandler, CreateBattleHandler createBattleHandler) {
        this.createGundamHandler = createGundamHandler;
        this.createKaijuHandler = createKaijuHandler;
        this.createBattleHandler = createBattleHandler;
    }

    @Autowired
    public GundamRepository gundamRepository;

    @Autowired
    public KaijuRepository kaijuRepository;

    @Autowired
    public BattleRepository battleRepository;

    @Before
    public void clearBattle() {
        battleRepository.deleteAllBattles();
    }

    public void createBattle() throws JSONException, IOException {
        JSONObject body = new JSONObject();
        body.put("gundamId", gundamReadModel.getId());
        body.put("kaijuId", kaijuReadModel.getId());

        executePost("/battle/create", body);
    }

    @Given ("A gundam was created with its name and model")
    public void aGundamWasCreatedWithItsNameAndModel(DataTable table) throws JSONException, IOException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String name = rows.get(0).get("name");
        String model = rows.get(0).get("model");

        gundamReadModel = createGundamHandler.handle(new CreateGundam(name, model));
    }

    @Given ("A kaiju was created with its name and species")
    public void aKaijuWasCreatedWithItsNameAndSpecies(DataTable table) throws JSONException, IOException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String name = rows.get(0).get("name");
        String species = rows.get(0).get("species");

        kaijuReadModel = createKaijuHandler.handle(new CreateKaiju(name, species));
    }

    @When ("I create a Battle")
    public void iCreateABattle() throws JSONException, IOException {
        createBattle();
    }

    @Then ("I should see a Battle with its status and turn")
    public void iShouldSeeABattleWithItsStatusAndTurn(DataTable table) throws IOException, JSONException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String status = rows.get(0).get("status");
        String turn = rows.get(0).get("turn");

        JSONObject body = new JSONObject(latestResponse.getBody());
        System.out.println(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(status, body.getString("status"));
        Assert.assertEquals(turn, body.getString("turn"));
    }
}
