package fr.aix.but.r404_20232024.domain.kaiju;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KaijuStatsTest {
    @Test
    void testConstructor() {
        KaijuStats actualKaijuStats = new KaijuStats(1, 2, 3, 4, 5, 6, 7);
        assertEquals(1, actualKaijuStats.maxHealth());
        assertEquals(2, actualKaijuStats.attack());
        assertEquals(3, actualKaijuStats.defense());
        assertEquals(4, actualKaijuStats.speed());
        assertEquals(5, actualKaijuStats.criticalChance());
        assertEquals(6, actualKaijuStats.evadeChance());
        assertEquals(7, actualKaijuStats.accuracy());
    }

}