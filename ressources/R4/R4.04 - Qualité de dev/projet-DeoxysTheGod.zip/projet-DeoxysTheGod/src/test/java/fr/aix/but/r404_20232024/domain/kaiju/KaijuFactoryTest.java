package fr.aix.but.r404_20232024.domain.kaiju;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class KaijuFactoryTest {
    KaijuStatsRepository kaijuStatsRepository;
    KaijuStats stats;
    KaijuFactory kaijuFactory;

    @BeforeEach
    void setUp() {
        kaijuStatsRepository = mock();
        stats = new KaijuStats(1, 2, 3, 4, 5, 6, 7);
        kaijuFactory = new KaijuFactory(kaijuStatsRepository);
    }

    @Test
    void fromAnguirusType() {
        KaijuStats stats = new KaijuStats(170, 76, 39, 8, 98, 9, 15);
        when(kaijuStatsRepository.fromType(KaijuType.ANGUIRUS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("ANGUIRUS", "bobby");
        assertEquals(KaijuType.ANGUIRUS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromBaragonType() {
        KaijuStats stats = new KaijuStats(266, 54, 81, 24, 29, 38, 97);
        when(kaijuStatsRepository.fromType(KaijuType.BARAGON)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("BARAGON", "bobby");
        assertEquals(KaijuType.BARAGON, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromBattraType() {
        KaijuStats stats = new KaijuStats(758, 22, 44, 48, 1, 13, 75);
        when(kaijuStatsRepository.fromType(KaijuType.BATTRA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("BATTRA", "bobby");
        assertEquals(KaijuType.BATTRA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromBiollanteType() {
        KaijuStats stats = new KaijuStats(723, 25, 18, 66, 24, 22, 44);
        when(kaijuStatsRepository.fromType(KaijuType.BIOLLANTE)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("BIOLLANTE", "bobby");
        assertEquals(KaijuType.BIOLLANTE, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromDestoroyahType() {
        KaijuStats stats = new KaijuStats(235, 95, 8, 48, 78, 76, 89);
        when(kaijuStatsRepository.fromType(KaijuType.DESTOROYAH)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("DESTOROYAH", "bobby");
        assertEquals(KaijuType.DESTOROYAH, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromEbirahType() {
        KaijuStats stats = new KaijuStats(795, 84, 99, 24, 92, 2, 53);
        when(kaijuStatsRepository.fromType(KaijuType.EBIRAH)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("EBIRAH", "bobby");
        assertEquals(KaijuType.EBIRAH, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromGabaraType() {
        KaijuStats stats = new KaijuStats(550, 75, 61, 89, 64, 89, 55);
        when(kaijuStatsRepository.fromType(KaijuType.GABARA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("GABARA", "bobby");
        assertEquals(KaijuType.GABARA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromGanimesType() {
        KaijuStats stats = new KaijuStats(622, 99, 86, 89, 2, 17, 96);
        when(kaijuStatsRepository.fromType(KaijuType.GANIMES)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("GANIMES", "bobby");
        assertEquals(KaijuType.GANIMES, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromGiganType() {
        KaijuStats stats = new KaijuStats(122, 89, 32, 50, 9, 43, 89);
        when(kaijuStatsRepository.fromType(KaijuType.GIGAN)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("GIGAN", "bobby");
        assertEquals(KaijuType.GIGAN, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromGodzillaType() {
        KaijuStats stats = new KaijuStats(884, 58, 11, 7, 84, 36, 10);
        when(kaijuStatsRepository.fromType(KaijuType.GODZILLA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("GODZILLA", "bobby");
        assertEquals(KaijuType.GODZILLA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromGorosaurusType() {
        KaijuStats stats = new KaijuStats(249, 57, 61, 6, 96, 83, 78);
        when(kaijuStatsRepository.fromType(KaijuType.GOROSAURUS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("GOROSAURUS", "bobby");
        assertEquals(KaijuType.GOROSAURUS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }


    @Test
    void fromGyaosType() {
        KaijuStats stats = new KaijuStats(807, 19, 12, 97, 56, 51, 32);
        when(kaijuStatsRepository.fromType(KaijuType.GYAOS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("GYAOS", "bobby");
        assertEquals(KaijuType.GYAOS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromHedorahType() {
        KaijuStats stats = new KaijuStats(430, 79, 25, 88, 57, 87, 40);
        when(kaijuStatsRepository.fromType(KaijuType.HEDORAH)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("HEDORAH", "bobby");
        assertEquals(KaijuType.HEDORAH, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromIrysType() {
        KaijuStats stats = new KaijuStats(801, 20, 68, 52, 68, 45, 15);
        when(kaijuStatsRepository.fromType(KaijuType.IRYS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("IRYS", "bobby");
        assertEquals(KaijuType.IRYS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromKamacurasType() {
        KaijuStats stats = new KaijuStats(480, 5, 45, 35, 45, 24, 66);
        when(kaijuStatsRepository.fromType(KaijuType.KAMACURAS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("KAMACURAS", "bobby");
        assertEquals(KaijuType.KAMACURAS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromKamoebasType() {
        KaijuStats stats = new KaijuStats(615, 42, 7, 81, 43, 68, 14);
        when(kaijuStatsRepository.fromType(KaijuType.KAMOEBAS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("KAMOEBAS", "bobby");
        assertEquals(KaijuType.KAMOEBAS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromKingCaesarType() {
        KaijuStats stats = new KaijuStats(457, 61, 69, 62, 48, 45, 78);
        when(kaijuStatsRepository.fromType(KaijuType.KING_CAESAR)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("KING_CAESAR", "bobby");
        assertEquals(KaijuType.KING_CAESAR, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromKingKongType() {
        KaijuStats stats = new KaijuStats(939, 64, 12, 23, 43, 79, 95);
        when(kaijuStatsRepository.fromType(KaijuType.KING_KONG)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("KING_KONG", "bobby");
        assertEquals(KaijuType.KING_KONG, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromKumongaType() {
        KaijuStats stats = new KaijuStats(627, 31, 65, 64, 89, 28, 10);
        when(kaijuStatsRepository.fromType(KaijuType.KUMONGA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("KUMONGA", "bobby");
        assertEquals(KaijuType.KUMONGA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromLegionType() {
        KaijuStats stats = new KaijuStats(700, 5, 61, 40, 1, 48, 9);
        when(kaijuStatsRepository.fromType(KaijuType.LEGION)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("LEGION", "bobby");
        assertEquals(KaijuType.LEGION, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMagumaType() {
        KaijuStats stats = new KaijuStats(223, 24, 8, 72, 64, 59, 29);
        when(kaijuStatsRepository.fromType(KaijuType.MAGUMA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MAGUMA", "bobby");
        assertEquals(KaijuType.MAGUMA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMandaType() {
        KaijuStats stats = new KaijuStats(760, 51, 10, 38, 77, 50, 89);
        when(kaijuStatsRepository.fromType(KaijuType.MANDA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MANDA", "bobby");
        assertEquals(KaijuType.MANDA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMatangoType() {
        KaijuStats stats = new KaijuStats(966, 52, 7, 25, 50, 75, 90);
        when(kaijuStatsRepository.fromType(KaijuType.MATANGO)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MATANGO", "bobby");
        assertEquals(KaijuType.MATANGO, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMechagodzillaType() {
        KaijuStats stats = new KaijuStats(780, 39, 72, 38, 29, 56, 7);
        when(kaijuStatsRepository.fromType(KaijuType.MECHAGODZILLA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MECHAGODZILLA", "bobby");
        assertEquals(KaijuType.MECHAGODZILLA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMechaniKongType() {
        KaijuStats stats = new KaijuStats(769, 37, 80, 17, 86, 58, 61);
        when(kaijuStatsRepository.fromType(KaijuType.MECHANI_KONG)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MECHANI_KONG", "bobby");
        assertEquals(KaijuType.MECHANI_KONG, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMegalonType() {
        KaijuStats stats = new KaijuStats(402, 74, 8, 22, 81, 5, 82);
        when(kaijuStatsRepository.fromType(KaijuType.MEGALON)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MEGALON", "bobby");
        assertEquals(KaijuType.MEGALON, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMinillaType() {
        KaijuStats stats = new KaijuStats(388, 42, 42, 46, 26, 9, 1);
        when(kaijuStatsRepository.fromType(KaijuType.MINILLA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MINILLA", "bobby");
        assertEquals(KaijuType.MINILLA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMogeraType() {
        KaijuStats stats = new KaijuStats(574, 46, 30, 27, 49, 14, 69);
        when(kaijuStatsRepository.fromType(KaijuType.MOGERA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MOGERA", "bobby");
        assertEquals(KaijuType.MOGERA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMogueraType() {
        KaijuStats stats = new KaijuStats(726, 75, 70, 16, 13, 62, 29);
        when(kaijuStatsRepository.fromType(KaijuType.MOGUERA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MOGUERA", "bobby");
        assertEquals(KaijuType.MOGUERA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromMothraType() {
        KaijuStats stats = new KaijuStats(960, 90, 39, 40, 23, 80, 83);
        when(kaijuStatsRepository.fromType(KaijuType.MOTHRA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("MOTHRA", "bobby");
        assertEquals(KaijuType.MOTHRA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromOodakaType() {
        KaijuStats stats = new KaijuStats(943, 94, 98, 92, 99, 77, 32);
        when(kaijuStatsRepository.fromType(KaijuType.OODAKA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("OODAKA", "bobby");
        assertEquals(KaijuType.OODAKA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromOrgaType() {
        KaijuStats stats = new KaijuStats(266, 52, 90, 77, 50, 82, 95);
        when(kaijuStatsRepository.fromType(KaijuType.ORGA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("ORGA", "bobby");
        assertEquals(KaijuType.ORGA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromRattlesnakeType() {
        KaijuStats stats = new KaijuStats(244, 56, 72, 18, 73, 58, 85);
        when(kaijuStatsRepository.fromType(KaijuType.RATTLESNAKE)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("RATTLESNAKE", "bobby");
        assertEquals(KaijuType.RATTLESNAKE, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromRodanType() {
        KaijuStats stats = new KaijuStats(154, 43, 35, 21, 25, 41, 12);
        when(kaijuStatsRepository.fromType(KaijuType.RODAN)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("RODAN", "bobby");
        assertEquals(KaijuType.RODAN, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromSpaceGodzillaType() {
        KaijuStats stats = new KaijuStats(579, 31, 13, 59, 2, 80, 70);
        when(kaijuStatsRepository.fromType(KaijuType.SPACE_GODZILLA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("SPACE_GODZILLA", "bobby");
        assertEquals(KaijuType.SPACE_GODZILLA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromTitanosaurusType() {
        KaijuStats stats = new KaijuStats(778, 88, 47, 42, 82, 34, 86);
        when(kaijuStatsRepository.fromType(KaijuType.TITANOSAURUS)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("TITANOSAURUS", "bobby");
        assertEquals(KaijuType.TITANOSAURUS, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromVaranType() {
        KaijuStats stats = new KaijuStats(893, 31, 6, 71, 44, 3, 73);
        when(kaijuStatsRepository.fromType(KaijuType.VARAN)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("VARAN", "bobby");
        assertEquals(KaijuType.VARAN, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromZigraType() {
        KaijuStats stats = new KaijuStats(768, 55, 94, 27, 54, 22, 11);
        when(kaijuStatsRepository.fromType(KaijuType.ZIGRA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("ZIGRA", "bobby");
        assertEquals(KaijuType.ZIGRA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromZillaType() {
        KaijuStats stats = new KaijuStats(819, 56, 31, 48, 70, 14, 7);
        when(kaijuStatsRepository.fromType(KaijuType.ZILLA)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("ZILLA", "bobby");
        assertEquals(KaijuType.ZILLA, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromZoneFighterType() {
        KaijuStats stats = new KaijuStats(548, 51, 46, 48, 66, 23, 3);
        when(kaijuStatsRepository.fromType(KaijuType.ZONE_FIGHTER)).thenReturn(stats);

        Kaiju kaiju = kaijuFactory.fromType("ZONE_FIGHTER", "bobby");
        assertEquals(KaijuType.ZONE_FIGHTER, kaiju.getType());
        assertEquals("bobby", kaiju.getName());
    }

    @Test
    void fromUnknownType() {
        assertThrows(IllegalArgumentException.class, () -> kaijuFactory.fromType("UNKNOWN", "bobby"));
    }

}