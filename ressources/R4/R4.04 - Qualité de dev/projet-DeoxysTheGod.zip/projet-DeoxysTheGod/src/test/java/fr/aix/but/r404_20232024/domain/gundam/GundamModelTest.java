package fr.aix.but.r404_20232024.domain.gundam;

import fr.aix.but.r404_20232024.domain.gundam.GundamModel;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GundamModelTest {
    
    @Test
    void testTypeCount() {
        assertEquals(20, GundamModel.values().length);
    }
    
    
    @Test
    void testRX_78_2() {
        assertEquals("RX-78-2", GundamModel.RX_78_2.getValue());
        assertEquals("RX_78_2", GundamModel.RX_78_2.name());
    }

    @Test
    void testZakuII() {
        assertEquals("Zaku II", GundamModel.ZAKU_II.getValue());
        assertEquals("ZAKU_II", GundamModel.ZAKU_II.name());
    }

    @Test
    void testZakuIIHighMobility() {
        assertEquals("Zaku II High Mobility", GundamModel.ZAKU_II_HIGH_MOBILITY.getValue());
        assertEquals("ZAKU_II_HIGH_MOBILITY", GundamModel.ZAKU_II_HIGH_MOBILITY.name());
    }

    @Test
    void testGundamBarbatos() {
        assertEquals("Gundam Barbatos", GundamModel.GUNDAM_BARBATOS.getValue());
        assertEquals("GUNDAM_BARBATOS", GundamModel.GUNDAM_BARBATOS.name());
    }

    @Test
    void testGundamBarbatosLupus() {
        assertEquals("Gundam Barbatos Lupus", GundamModel.GUNDAM_BARBATOS_LUPUS.getValue());
        assertEquals("GUNDAM_BARBATOS_LUPUS", GundamModel.GUNDAM_BARBATOS_LUPUS.name());
    }

    @Test
    void testGundamBarbatosLupusRex() {
        assertEquals("Gundam Barbatos Lupus Rex", GundamModel.GUNDAM_BARBATOS_LUPUS_REX.getValue());
        assertEquals("GUNDAM_BARBATOS_LUPUS_REX", GundamModel.GUNDAM_BARBATOS_LUPUS_REX.name());
    }

    @Test
    void testGundamAstrayRedFrame() {
        assertEquals("Gundam Astray Red Frame", GundamModel.GUNDAM_ASTRAY_RED_FRAME.getValue());
        assertEquals("GUNDAM_ASTRAY_RED_FRAME", GundamModel.GUNDAM_ASTRAY_RED_FRAME.name());
    }

    @Test
    void testGundamAstrayBlueFrame() {
        assertEquals("Gundam Astray Blue Frame", GundamModel.GUNDAM_ASTRAY_BLUE_FRAME.getValue());
        assertEquals("GUNDAM_ASTRAY_BLUE_FRAME", GundamModel.GUNDAM_ASTRAY_BLUE_FRAME.name());
    }

    @Test
    void testGundamAstrayGoldFrameAmatsu() {
        assertEquals("Gundam Astray Gold Frame Amatsu", GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU.getValue());
        assertEquals("GUNDAM_ASTRAY_GOLD_FRAME_AMATSU", GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU.name());
    }

    @Test
    void testGundamAstrayGoldFrameAmatsuMina() {
        assertEquals("Gundam Astray Gold Frame Amatsu Mina", GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA.getValue());
        assertEquals("GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA", GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA.name());
    }

    @Test
    void testGundamExia() {
        assertEquals("Gundam Exia", GundamModel.GUNDAM_EXIA.getValue());
        assertEquals("GUNDAM_EXIA", GundamModel.GUNDAM_EXIA.name());
    }

    @Test
    void testGundamExiaRepair() {
        assertEquals("Gundam Exia Repair", GundamModel.GUNDAM_EXIA_REPAIR.getValue());
        assertEquals("GUNDAM_EXIA_REPAIR", GundamModel.GUNDAM_EXIA_REPAIR.name());
    }

    @Test
    void testGundamExiaRepairII() {
        assertEquals("Gundam Exia Repair II", GundamModel.GUNDAM_EXIA_REPAIR_II.getValue());
        assertEquals("GUNDAM_EXIA_REPAIR_II", GundamModel.GUNDAM_EXIA_REPAIR_II.name());
    }

    @Test
    void testGundamExiaDarkMatter() {
        assertEquals("Gundam Exia Dark Matter", GundamModel.GUNDAM_EXIA_DARK_MATTER.getValue());
        assertEquals("GUNDAM_EXIA_DARK_MATTER", GundamModel.GUNDAM_EXIA_DARK_MATTER.name());
    }

    @Test
    void testGundamDynames() {
        assertEquals("Gundam Dynames", GundamModel.GUNDAM_DYNAMES.getValue());
        assertEquals("GUNDAM_DYNAMES", GundamModel.GUNDAM_DYNAMES.name());
    }

    @Test
    void testGundamWingZero() {
        assertEquals("Gundam Wing Zero", GundamModel.GUNDAM_WING_ZERO.getValue());
        assertEquals("GUNDAM_WING_ZERO", GundamModel.GUNDAM_WING_ZERO.name());
    }

    @Test
    void testGundamEpyon() {
        assertEquals("Gundam Epyon", GundamModel.GUNDAM_EPYON.getValue());
        assertEquals("GUNDAM_EPYON", GundamModel.GUNDAM_EPYON.name());
    }

    @Test
    void testGundamHeavyarms() {
        assertEquals("Gundam Heavyarms", GundamModel.GUNDAM_HEAVYARMS.getValue());
        assertEquals("GUNDAM_HEAVYARMS", GundamModel.GUNDAM_HEAVYARMS.name());
    }

    @Test
    void testGundamSandrock() {
        assertEquals("Gundam Sandrock", GundamModel.GUNDAM_SANDROCK.getValue());
        assertEquals("GUNDAM_SANDROCK", GundamModel.GUNDAM_SANDROCK.name());
    }

    @Test
    void testTallgeese() {
        assertEquals("Tallgeese", GundamModel.TALLGEESE.getValue());
        assertEquals("TALLGEESE", GundamModel.TALLGEESE.name());
    }
}
