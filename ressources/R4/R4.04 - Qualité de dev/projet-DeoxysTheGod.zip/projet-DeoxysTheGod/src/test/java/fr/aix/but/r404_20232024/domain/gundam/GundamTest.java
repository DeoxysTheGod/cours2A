package fr.aix.but.r404_20232024.domain.gundam;

import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.gundam.GundamStats;
import fr.aix.but.r404_20232024.domain.gundam.GundamModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GundamTest {

    GundamStats stats;
    Gundam gundam;

    @BeforeEach
    void setUp() {
        stats = new GundamStats(1, 2, 3, 4, 5, 6, 7);
        gundam = Gundam.create("name", GundamModel.GUNDAM_ASTRAY_BLUE_FRAME, stats);
    }

    @Test
    void create() {
        assertNotNull(gundam);
    }

    @Test
    void readModel() {
        assertNotNull(gundam.readModel());
    }

    @Test
    void getId() {
        assertNotNull(gundam.getId().getId());
        UUID parsed = UUID.fromString(gundam.getId().getId());
        assertEquals(gundam.getId().getId(), parsed.toString());
    }

    @Test
    void getName() {
        assertEquals("name", gundam.getName());
    }

    @Test
    void getHealth() {
        assertEquals(1, gundam.getHealth());
    }

    @Test
    void getMaxHealth() {
        assertEquals(1, gundam.getMaxHealth());
    }

    @Test
    void getAttack() {
        assertEquals(2*1.5, gundam.getAttack());
    }

    @Test
    void getDefense() {
        assertEquals(3, gundam.getDefense());
    }

    @Test
    void getSpeed() {
        assertEquals(4*1.5, gundam.getSpeed());
    }

    @Test
    void getCriticalChance() {
        assertEquals(5, gundam.getCriticalChance());
    }

    @Test
    void getEvadeChance() {
        assertEquals(6, gundam.getEvadeChance());
    }

    @Test
    void getAccuracy() {
        assertEquals(7, gundam.getAccuracy());
    }

    @Test
    void takeDamage() {
        assertEquals(0, gundam.takeDamage(1));

        assertEquals(0, gundam.takeDamage(2));

        // 5 - 3 = 2 = 2
        assertEquals(2, gundam.takeDamage(5));

        // 6 - 3 = 3 = 3
        assertEquals(3, gundam.takeDamage(6));
    }

    @Test
    void takeDamageWithNegativeDamage() {
        assertEquals(0, gundam.takeDamage(-1));
    }

    @Test
    void takeDamageWithNegativeHealthAndNegativeDefenseAndNegativeDamage() {
        stats = new GundamStats(-1, 2, -3, 4, 5, 6, 7);
        gundam = Gundam.create("name", GundamModel.GUNDAM_ASTRAY_BLUE_FRAME, stats);

        assertEquals(0, gundam.takeDamage(-5));
    }

    @Test
    void takeDamageWithNegativeHealthAndNegativeDamage() {
        stats = new GundamStats(-1, 2, 3, 4, 5, 6, 7);
        gundam = Gundam.create("name", GundamModel.GUNDAM_ASTRAY_BLUE_FRAME, stats);

        assertEquals(0, gundam.takeDamage(-5));
    }


    @Test
    void getGundamModel() {
        assertEquals(GundamModel.GUNDAM_ASTRAY_BLUE_FRAME, gundam.getModel());
    }
}
