package fr.aix.but.r404_20232024.domain.kaiju;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class KaijuTypeTest {
    @Test
    void testTypeCount() {
        assertEquals(40, KaijuType.values().length);
    }

    // Generate tests for all types stored in KaijuType.java

    @Test
    void testAnguirusType() {
        assertEquals("Anguirus", KaijuType.ANGUIRUS.getValue());
        assertEquals("ANGUIRUS", KaijuType.ANGUIRUS.name());
    }

    @Test
    void testBaragonType() {
        assertEquals("Baragon", KaijuType.BARAGON.getValue());
        assertEquals("BARAGON", KaijuType.BARAGON.name());
    }

    @Test
    void testBattraType() {
        assertEquals("Battra", KaijuType.BATTRA.getValue());
        assertEquals("BATTRA", KaijuType.BATTRA.name());
    }

    @Test
    void testBiollanteType() {
        assertEquals("Biollante", KaijuType.BIOLLANTE.getValue());
        assertEquals("BIOLLANTE", KaijuType.BIOLLANTE.name());
    }

    @Test
    void testDestoroyahType() {
        assertEquals("Destoroyah", KaijuType.DESTOROYAH.getValue());
        assertEquals("DESTOROYAH", KaijuType.DESTOROYAH.name());
    }

    @Test
    void testEbirahType() {
        assertEquals("Ebirah", KaijuType.EBIRAH.getValue());
        assertEquals("EBIRAH", KaijuType.EBIRAH.name());
    }

    @Test
    void testGameraType() {
        assertEquals("Gabara", KaijuType.GABARA.getValue());
        assertEquals("GABARA", KaijuType.GABARA.name());
    }

    @Test
    void testGanimesType() {
        assertEquals("Ganimes", KaijuType.GANIMES.getValue());
        assertEquals("GANIMES", KaijuType.GANIMES.name());
    }

    @Test
    void testGiganType() {
        assertEquals("Gigan", KaijuType.GIGAN.getValue());
        assertEquals("GIGAN", KaijuType.GIGAN.name());
    }

    @Test
    void testGodzillaType() {
        assertEquals("Godzilla", KaijuType.GODZILLA.getValue());
        assertEquals("GODZILLA", KaijuType.GODZILLA.name());
    }

    @Test
    void testGorosaurusType() {
        assertEquals("Gorosaurus", KaijuType.GOROSAURUS.getValue());
        assertEquals("GOROSAURUS", KaijuType.GOROSAURUS.name());
    }

    @Test
    void testGyaosType() {
        assertEquals("Gyaos", KaijuType.GYAOS.getValue());
        assertEquals("GYAOS", KaijuType.GYAOS.name());
    }

    @Test
    void testHedorahType() {
        assertEquals("Hedorah", KaijuType.HEDORAH.getValue());
        assertEquals("HEDORAH", KaijuType.HEDORAH.name());
    }

    @Test
    void testIrysType() {
        assertEquals("Irys", KaijuType.IRYS.getValue());
        assertEquals("IRYS", KaijuType.IRYS.name());
    }

    @Test
    void testKamacurasType() {
        assertEquals("Kamacuras", KaijuType.KAMACURAS.getValue());
        assertEquals("KAMACURAS", KaijuType.KAMACURAS.name());
    }

    @Test
    void testKamoebasType() {
        assertEquals("Kamoebas", KaijuType.KAMOEBAS.getValue());
        assertEquals("KAMOEBAS", KaijuType.KAMOEBAS.name());
    }

    @Test
    void testKingCaesarType() {
        assertEquals("King Caesar", KaijuType.KING_CAESAR.getValue());
        assertEquals("KING_CAESAR", KaijuType.KING_CAESAR.name());
    }

    @Test
    void testKingKongType() {
        assertEquals("King Kong", KaijuType.KING_KONG.getValue());
        assertEquals("KING_KONG", KaijuType.KING_KONG.name());
    }

    @Test
    void testKumongaType() {
        assertEquals("Kumonga", KaijuType.KUMONGA.getValue());
        assertEquals("KUMONGA", KaijuType.KUMONGA.name());
    }

    @Test
    void testLegionType() {
        assertEquals("Legion", KaijuType.LEGION.getValue());
        assertEquals("LEGION", KaijuType.LEGION.name());
    }

    @Test
    void testMagumaType() {
        assertEquals("Maguma", KaijuType.MAGUMA.getValue());
        assertEquals("MAGUMA", KaijuType.MAGUMA.name());
    }

    @Test
    void testMandaType() {
        assertEquals("Manda", KaijuType.MANDA.getValue());
        assertEquals("MANDA", KaijuType.MANDA.name());
    }

    @Test
    void testMatangoType() {
        assertEquals("Matango", KaijuType.MATANGO.getValue());
        assertEquals("MATANGO", KaijuType.MATANGO.name());
    }

    @Test
    void testMechagodzillaType() {
        assertEquals("Mechagodzilla", KaijuType.MECHAGODZILLA.getValue());
        assertEquals("MECHAGODZILLA", KaijuType.MECHAGODZILLA.name());
    }

    @Test
    void testMechaniKongType() {
        assertEquals("Mechani-Kong", KaijuType.MECHANI_KONG.getValue());
        assertEquals("MECHANI_KONG", KaijuType.MECHANI_KONG.name());
    }

    @Test
    void testMegalonType() {
        assertEquals("Megalon", KaijuType.MEGALON.getValue());
        assertEquals("MEGALON", KaijuType.MEGALON.name());
    }

    @Test
    void testMinillaType() {
        assertEquals("Minilla", KaijuType.MINILLA.getValue());
        assertEquals("MINILLA", KaijuType.MINILLA.name());
    }

    @Test
    void testMogeraType() {
        assertEquals("Mogera", KaijuType.MOGERA.getValue());
        assertEquals("MOGERA", KaijuType.MOGERA.name());
    }

    @Test
    void testMogueraType() {
        assertEquals("Moguera", KaijuType.MOGUERA.getValue());
        assertEquals("MOGUERA", KaijuType.MOGUERA.name());
    }

    @Test
    void testMothraType() {
        assertEquals("Mothra", KaijuType.MOTHRA.getValue());
        assertEquals("MOTHRA", KaijuType.MOTHRA.name());
    }

    @Test
    void testOodakaType() {
        assertEquals("Oodaka", KaijuType.OODAKA.getValue());
        assertEquals("OODAKA", KaijuType.OODAKA.name());
    }

    @Test
    void testOrgaType() {
        assertEquals("Orga", KaijuType.ORGA.getValue());
        assertEquals("ORGA", KaijuType.ORGA.name());
    }

    @Test
    void testRattlesnakeType() {
        assertEquals("Rattlesnake", KaijuType.RATTLESNAKE.getValue());
        assertEquals("RATTLESNAKE", KaijuType.RATTLESNAKE.name());
    }

    @Test
    void testRodanType() {
        assertEquals("Rodan", KaijuType.RODAN.getValue());
        assertEquals("RODAN", KaijuType.RODAN.name());
    }

    @Test
    void testSpaceGodzillaType() {
        assertEquals("Space Godzilla", KaijuType.SPACE_GODZILLA.getValue());
        assertEquals("SPACE_GODZILLA", KaijuType.SPACE_GODZILLA.name());
    }

    @Test
    void testTitanosaurusType() {
        assertEquals("Titanosaurus", KaijuType.TITANOSAURUS.getValue());
        assertEquals("TITANOSAURUS", KaijuType.TITANOSAURUS.name());
    }

    @Test
    void testVaranType() {
        assertEquals("Varan", KaijuType.VARAN.getValue());
        assertEquals("VARAN", KaijuType.VARAN.name());
    }

    @Test
    void testZigraType() {
        assertEquals("Zigra", KaijuType.ZIGRA.getValue());
        assertEquals("ZIGRA", KaijuType.ZIGRA.name());
    }

    @Test
    void testZillaType() {
        assertEquals("Zilla", KaijuType.ZILLA.getValue());
        assertEquals("ZILLA", KaijuType.ZILLA.name());
    }

    @Test
    void testZoneFighterType() {
        assertEquals("Zone Fighter", KaijuType.ZONE_FIGHTER.getValue());
        assertEquals("ZONE_FIGHTER", KaijuType.ZONE_FIGHTER.name());
    }
}