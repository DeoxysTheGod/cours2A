package fr.aix.but.r404_20232024;

import fr.aix.but.r404_20232024.SpringIntegrationTest;
import fr.aix.but.r404_20232024.application.command.gundam.createGundam.CreateGundam;
import fr.aix.but.r404_20232024.application.command.gundam.createGundam.CreateGundamHandler;
import fr.aix.but.r404_20232024.domain.gundam.GundamRepository;
import fr.aix.but.r404_20232024.domain.gundam.readModel.GundamReadModel;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class GundamStepsDefinition extends SpringIntegrationTest {

    CreateGundamHandler createGundamHandler;
    private GundamReadModel gundamReadModel;

    @Autowired
    public GundamStepsDefinition(CreateGundamHandler createGundamHandler) {
        this.createGundamHandler = createGundamHandler;
    }

    @Autowired
    public GundamRepository gundamRepository;

    @Before
    public void clearGundam() {
        gundamRepository.deleteAllGundam();
    }

    // Create Gundam
    @When("I create a Gundam with its name and model")
    public void iCreateAGundamWithItsNameAndModel(DataTable table) throws JSONException, IOException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String name = rows.get(0).get("name");
        String model = rows.get(0).get("model");

        createGundam(name, model);
    }

    private void createGundam(String name, String model) throws JSONException, IOException {
        JSONObject body = new JSONObject();
        body.put("name", name);
        body.put("model", model);

        executePost("/gundam/create", body);
    }

    @Given("A Gundam was created")
    public void aGundamWasCreated() throws JSONException, IOException {
        gundamReadModel = createGundamHandler.handle(new CreateGundam("Gundam-chan", "RX_78_2"));
    }

    @Then("I should see a Gundam with its name and model")
    public void iShouldSeeAGundamWithItsNameAndModel(DataTable table) throws IOException, JSONException {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        String name = rows.get(0).get("name");
        String model = rows.get(0).get("model");

        JSONObject body = new JSONObject(latestResponse.getBody());
        System.out.println(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(name, body.getString("name"));
        Assert.assertEquals(model, body.getString("model"));
    }

    // List Gundam
    @When("I list Gundam")
    public void iListGundam() throws IOException, JSONException {
        executeGet("/gundam/list");
    }

    @Then("I should have {int} Gundam")
    public void iShouldHaveGundam(int count) throws JSONException, IOException {

        JSONArray body = new JSONArray(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(count, body.length());
    }

    // Gundam details
    @When("I detail Gundam")
    public void iDetailGundam() throws IOException {
        executeGet("/gundam/" + gundamReadModel.getId() + "/detail");
    }

    @When("I list Gundam model")
    public void iListGundamModel() throws IOException {
        executeGet("/gundam/list-model");
    }

    @Then("I should have {int} Gundam model")
    public void iShouldHaveGundamModel(int count) throws JSONException, IOException {
        JSONArray body = new JSONArray(latestResponse.getBody());
        Assert.assertEquals(HttpStatus.OK, latestResponse.getTheResponse().getStatusCode());
        Assert.assertEquals(count, body.length());
    }
}
