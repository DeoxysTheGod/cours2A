package fr.aix.but.r404_20232024.domain.gundam;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class GundamFactoryTest {
    GundamStatsRepository gundamStatsRepository;
    GundamStats stats;
    GundamFactory gundamFactory;

    @BeforeEach
    void setUp() {
        gundamStatsRepository = mock();
        stats = new GundamStats(1, 2, 3, 4, 5, 6, 7);
        gundamFactory = new GundamFactory(gundamStatsRepository);
    }

    @Test
    void fromRX78_2Type() {
        GundamStats stats = new GundamStats(125, 55, 86, 62, 84, 26, 12);
        when(gundamStatsRepository.fromType(GundamModel.RX_78_2)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("RX_78_2", "bobby");
        assertEquals(GundamModel.RX_78_2, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromZakuIIType() {
        GundamStats stats = new GundamStats(440, 43, 88, 16, 73, 29, 11);
        when(gundamStatsRepository.fromType(GundamModel.ZAKU_II)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("ZAKU_II", "bobby");
        assertEquals(GundamModel.ZAKU_II, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamBarbatosLupusRexType() {
        GundamStats stats = new GundamStats(989, 95, 36, 21, 69, 41, 11);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS_LUPUS_REX)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_BARBATOS_LUPUS_REX", "bobby");
        assertEquals(GundamModel.GUNDAM_BARBATOS_LUPUS_REX, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamAstrayRedFrameType() {
        GundamStats stats = new GundamStats(791, 83, 97, 37, 79, 64, 21);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_RED_FRAME)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_ASTRAY_RED_FRAME", "bobby");
        assertEquals(GundamModel.GUNDAM_ASTRAY_RED_FRAME, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamAstrayBlueFrameType() {
        GundamStats stats = new GundamStats(448, 19, 41, 47, 8, 23, 82);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_BLUE_FRAME)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_ASTRAY_BLUE_FRAME", "bobby");
        assertEquals(GundamModel.GUNDAM_ASTRAY_BLUE_FRAME, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamAstrayGoldFrameAmatsuType() {
        GundamStats stats = new GundamStats(528, 74, 42, 29, 37, 78, 77);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_ASTRAY_GOLD_FRAME_AMATSU", "bobby");
        assertEquals(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamAstrayGoldFrameAmatsuMinaType() {
        GundamStats stats = new GundamStats(926, 13, 9, 20, 10, 84, 80);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA", "bobby");
        assertEquals(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamExiaType() {
        GundamStats stats = new GundamStats(142, 84, 32, 75, 21, 87, 48);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_EXIA", "bobby");
        assertEquals(GundamModel.GUNDAM_EXIA, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamExiaRepairType() {
        GundamStats stats = new GundamStats(595, 98, 62, 84, 18, 15, 16);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_REPAIR)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_EXIA_REPAIR", "bobby");
        assertEquals(GundamModel.GUNDAM_EXIA_REPAIR, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamExiaRepairIiType() {
        GundamStats stats = new GundamStats(231, 94, 50, 38, 82, 22, 86);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_REPAIR_II)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_EXIA_REPAIR_II", "bobby");
        assertEquals(GundamModel.GUNDAM_EXIA_REPAIR_II, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamExiaDarkMatterType() {
        GundamStats stats = new GundamStats(379, 100, 34, 88, 100, 51, 63);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_DARK_MATTER)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_EXIA_DARK_MATTER", "bobby");
        assertEquals(GundamModel.GUNDAM_EXIA_DARK_MATTER, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamDynamesType() {
        GundamStats stats = new GundamStats(248, 48, 74, 50, 52, 49, 89);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_DYNAMES)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_DYNAMES", "bobby");
        assertEquals(GundamModel.GUNDAM_DYNAMES, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamWingZeroType() {
        GundamStats stats = new GundamStats(490, 28, 18, 55, 20, 9, 22);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_WING_ZERO)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_WING_ZERO", "bobby");
        assertEquals(GundamModel.GUNDAM_WING_ZERO, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamEpyonType() {
        GundamStats stats = new GundamStats(803, 18, 67, 30, 84, 72, 97);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_EPYON)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_EPYON", "bobby");
        assertEquals(GundamModel.GUNDAM_EPYON, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamHeavyarmsType() {
        GundamStats stats = new GundamStats(131, 11, 66, 79, 92, 11, 70);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_HEAVYARMS)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_HEAVYARMS", "bobby");
        assertEquals(GundamModel.GUNDAM_HEAVYARMS, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromGundamSandrockType() {
        GundamStats stats = new GundamStats(297, 64, 91, 46, 91, 5, 100);
        when(gundamStatsRepository.fromType(GundamModel.GUNDAM_SANDROCK)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("GUNDAM_SANDROCK", "bobby");
        assertEquals(GundamModel.GUNDAM_SANDROCK, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

    @Test
    void fromTallgeeseType() {
        GundamStats stats = new GundamStats(486, 41, 85, 28, 48, 39, 47);
        when(gundamStatsRepository.fromType(GundamModel.TALLGEESE)).thenReturn(stats);

        Gundam gundam = gundamFactory.fromType("TALLGEESE", "bobby");
        assertEquals(GundamModel.TALLGEESE, gundam.getModel());
        assertEquals("bobby", gundam.getName());
    }

}
