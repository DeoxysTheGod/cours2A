package fr.aix.but.r404_20232024.infrastructure.repository.gundam;

import fr.aix.but.r404_20232024.domain.gundam.Gundam;
import fr.aix.but.r404_20232024.domain.shared.Id;
import fr.aix.but.r404_20232024.domain.shared.exceptions.NotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class InMemoryGundamRepositoryTest {

    Gundam gundam;
    Id id;
    InMemoryGundamRepository inMemoryGundamRepository;
    @BeforeEach
    void setUp() {
        gundam = mock();
        id = mock();
        when(id.getId()).thenReturn("id");
        when(gundam.getId()).thenReturn(id);
        inMemoryGundamRepository = new InMemoryGundamRepository();
    }

    @Test
    void testEmpty() {
        assertTrue(inMemoryGundamRepository.getAllGundam().isEmpty());
    }

    @Test
    void testSave() {
        assertTrue(inMemoryGundamRepository.getAllGundam().isEmpty());
        inMemoryGundamRepository.save(gundam);
        assertFalse(inMemoryGundamRepository.getAllGundam().isEmpty());
    }

    @Test
    void testGetGundamByIdWhenGundamExists() {
        inMemoryGundamRepository.save(gundam);
        assertEquals(gundam, inMemoryGundamRepository.find(id));
    }

    @Test
    void testGetGundamByIdWhenGundamDoesNotExist() {
        assertThrows(NotFoundException.class, () -> inMemoryGundamRepository.find(id));
    }

    @Test
    void testGetGundamByIdWhenAnotherGundamExists() {
        Gundam gundam2 = mock();
        Id id2 = mock();
        when(id2.getId()).thenReturn("id2");
        when(gundam2.getId()).thenReturn(id2);
        inMemoryGundamRepository.save(gundam);
        inMemoryGundamRepository.save(gundam2);
        assertEquals(gundam2, inMemoryGundamRepository.find(id2));
    }

    @Test
    void testGetGundamByIdWhenAnotherGundamDoesNotExist() {
        Gundam gundam2 = mock();
        Id id2 = mock();
        when(id2.getId()).thenReturn("id2");
        when(gundam2.getId()).thenReturn(id2);
        inMemoryGundamRepository.save(gundam);
        assertThrows(NotFoundException.class, () -> inMemoryGundamRepository.find(id2));
    }

}