package fr.aix.but.r404_20232024.domain.gundam.readModel;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GundamReadModelTest {
    @org.junit.jupiter.api.Test
    void testConstructor() {
        GundamReadModel actualGundamReadModel = new GundamReadModel(
                "Name", "Name", "Type",
                2, 3, 4, 5, 6, 7, 8, 9);
        assertEquals("Name", actualGundamReadModel.getName());
        assertEquals("Type", actualGundamReadModel.getModel());
        assertEquals(2, actualGundamReadModel.getMaxHealth());
        assertEquals(3, actualGundamReadModel.getCurrentHealth());
        assertEquals(4, actualGundamReadModel.getAttack());
        assertEquals(5, actualGundamReadModel.getDefense());
        assertEquals(6, actualGundamReadModel.getSpeed());
        assertEquals(7, actualGundamReadModel.getCriticalChance());
        assertEquals(8, actualGundamReadModel.getEvadeChance());
        assertEquals(9, actualGundamReadModel.getAccuracy());
    }
}