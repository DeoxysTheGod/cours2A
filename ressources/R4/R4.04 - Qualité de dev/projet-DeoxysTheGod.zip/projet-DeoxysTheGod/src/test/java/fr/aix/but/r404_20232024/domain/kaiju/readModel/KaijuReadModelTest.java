package fr.aix.but.r404_20232024.domain.kaiju.readModel;

import static org.junit.jupiter.api.Assertions.*;

class KaijuReadModelTest {
    @org.junit.jupiter.api.Test
    void testConstructor() {
        KaijuReadModel actualKaijuReadModel = new KaijuReadModel(
                "Name", "Name", "Type",
                2, 3, 4, 5, 6, 7, 8, 9);
        assertEquals("Name", actualKaijuReadModel.getName());
        assertEquals("Type", actualKaijuReadModel.getType());
        assertEquals(2, actualKaijuReadModel.getMaxHealth());
        assertEquals(3, actualKaijuReadModel.getCurrentHealth());
        assertEquals(4, actualKaijuReadModel.getAttack());
        assertEquals(5, actualKaijuReadModel.getDefense());
        assertEquals(6, actualKaijuReadModel.getSpeed());
        assertEquals(7, actualKaijuReadModel.getCriticalChance());
        assertEquals(8, actualKaijuReadModel.getEvadeChance());
        assertEquals(9, actualKaijuReadModel.getAccuracy());
    }
}