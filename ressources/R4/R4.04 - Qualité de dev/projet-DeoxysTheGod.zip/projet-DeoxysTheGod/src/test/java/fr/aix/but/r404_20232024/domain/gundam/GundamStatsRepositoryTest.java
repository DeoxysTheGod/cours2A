package fr.aix.but.r404_20232024.domain.gundam;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GundamStatsRepositoryTest {
    GundamStatsRepository gundamStatsRepository;
    @BeforeEach
    void setUp() {
        gundamStatsRepository = new GundamStatsRepository();
    }

    @Test
    void fromRx78_2Type() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.RX_78_2);
        assertEquals(125, stats.maxHealth());
        assertEquals(55, stats.attack());
        assertEquals(86, stats.defense());
        assertEquals(62, stats.speed());
        assertEquals(84, stats.criticalChance());
        assertEquals(26, stats.evadeChance());
        assertEquals(12, stats.accuracy());
    }

    @Test
    void fromZakuIIType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.ZAKU_II);
        assertEquals(440, stats.maxHealth());
        assertEquals(43, stats.attack());
        assertEquals(88, stats.defense());
        assertEquals(16, stats.speed());
        assertEquals(73, stats.criticalChance());
        assertEquals(29, stats.evadeChance());
        assertEquals(11, stats.accuracy());
    }

    @Test
    void fromZakuIIHighMobilityType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.ZAKU_II_HIGH_MOBILITY);
        assertEquals(317, stats.maxHealth());
        assertEquals(34, stats.attack());
        assertEquals(60, stats.defense());
        assertEquals(76, stats.speed());
        assertEquals(89, stats.criticalChance());
        assertEquals(55, stats.evadeChance());
        assertEquals(52, stats.accuracy());
    }

    @Test
    void fromGundamBarbatosType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS);
        assertEquals(758, stats.maxHealth());
        assertEquals(23, stats.attack());
        assertEquals(65, stats.defense());
        assertEquals(58, stats.speed());
        assertEquals(93, stats.criticalChance());
        assertEquals(8, stats.evadeChance());
        assertEquals(71, stats.accuracy());
    }

    @Test
    void fromGundamBarbatosLupusType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS_LUPUS);
        assertEquals(245, stats.maxHealth());
        assertEquals(34, stats.attack());
        assertEquals(8, stats.defense());
        assertEquals(45, stats.speed());
        assertEquals(99, stats.criticalChance());
        assertEquals(69, stats.evadeChance());
        assertEquals(37, stats.accuracy());
    }

    @Test
    void fromGundamBarbatosLupusRexType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_BARBATOS_LUPUS_REX);
        assertEquals(989, stats.maxHealth());
        assertEquals(95, stats.attack());
        assertEquals(36, stats.defense());
        assertEquals(21, stats.speed());
        assertEquals(69, stats.criticalChance());
        assertEquals(41, stats.evadeChance());
        assertEquals(11, stats.accuracy());
    }

    @Test
    void fromGundamAstrayRedFrameType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_RED_FRAME);
        assertEquals(791, stats.maxHealth());
        assertEquals(83, stats.attack());
        assertEquals(97, stats.defense());
        assertEquals(37, stats.speed());
        assertEquals(79, stats.criticalChance());
        assertEquals(64, stats.evadeChance());
        assertEquals(21, stats.accuracy());
    }

    @Test
    void fromGundamAstrayBlueFrameType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_BLUE_FRAME);
        assertEquals(448, stats.maxHealth());
        assertEquals(19, stats.attack());
        assertEquals(41, stats.defense());
        assertEquals(47, stats.speed());
        assertEquals(8, stats.criticalChance());
        assertEquals(23, stats.evadeChance());
        assertEquals(82, stats.accuracy());
    }

    @Test
    void fromGundamAstrayGoldFrameAmatsuType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU);
        assertEquals(528, stats.maxHealth());
        assertEquals(74, stats.attack());
        assertEquals(42, stats.defense());
        assertEquals(29, stats.speed());
        assertEquals(37, stats.criticalChance());
        assertEquals(78, stats.evadeChance());
        assertEquals(77, stats.accuracy());
    }

    @Test
    void fromGundamAstrayGoldFrameAmatsuMinaType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_ASTRAY_GOLD_FRAME_AMATSU_MINA);
        assertEquals(926, stats.maxHealth());
        assertEquals(13, stats.attack());
        assertEquals(9, stats.defense());
        assertEquals(20, stats.speed());
        assertEquals(10, stats.criticalChance());
        assertEquals(84, stats.evadeChance());
        assertEquals(80, stats.accuracy());
    }

    @Test
    void fromGundamExiaType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA);
        assertEquals(142, stats.maxHealth());
        assertEquals(84, stats.attack());
        assertEquals(32, stats.defense());
        assertEquals(75, stats.speed());
        assertEquals(21, stats.criticalChance());
        assertEquals(87, stats.evadeChance());
        assertEquals(48, stats.accuracy());
    }

    @Test
    void fromGundamExiaRepairType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_REPAIR);
        assertEquals(595, stats.maxHealth());
        assertEquals(98, stats.attack());
        assertEquals(62, stats.defense());
        assertEquals(84, stats.speed());
        assertEquals(18, stats.criticalChance());
        assertEquals(15, stats.evadeChance());
        assertEquals(16, stats.accuracy());
    }

    @Test
    void fromGundamExiaRepairIiType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_REPAIR_II);
        assertEquals(231, stats.maxHealth());
        assertEquals(94, stats.attack());
        assertEquals(50, stats.defense());
        assertEquals(38, stats.speed());
        assertEquals(82, stats.criticalChance());
        assertEquals(22, stats.evadeChance());
        assertEquals(86, stats.accuracy());
    }

    @Test
    void fromGundamExiaDarkMatterType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_EXIA_DARK_MATTER);
        assertEquals(379, stats.maxHealth());
        assertEquals(100, stats.attack());
        assertEquals(34, stats.defense());
        assertEquals(88, stats.speed());
        assertEquals(100, stats.criticalChance());
        assertEquals(51, stats.evadeChance());
        assertEquals(63, stats.accuracy());
    }

    @Test
    void fromGundamDynamesType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_DYNAMES);
        assertEquals(248, stats.maxHealth());
        assertEquals(48, stats.attack());
        assertEquals(74, stats.defense());
        assertEquals(50, stats.speed());
        assertEquals(52, stats.criticalChance());
        assertEquals(49, stats.evadeChance());
        assertEquals(89, stats.accuracy());
    }

    @Test
    void fromGundamWingZeroType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_WING_ZERO);
        assertEquals(490, stats.maxHealth());
        assertEquals(28, stats.attack());
        assertEquals(18, stats.defense());
        assertEquals(55, stats.speed());
        assertEquals(20, stats.criticalChance());
        assertEquals(9, stats.evadeChance());
        assertEquals(22, stats.accuracy());
    }

    @Test
    void fromGundamEpyonType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_EPYON);
        assertEquals(803, stats.maxHealth());
        assertEquals(18, stats.attack());
        assertEquals(67, stats.defense());
        assertEquals(30, stats.speed());
        assertEquals(84, stats.criticalChance());
        assertEquals(72, stats.evadeChance());
        assertEquals(97, stats.accuracy());
    }

    @Test
    void fromGundamHeavyarmsType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_HEAVYARMS);
        assertEquals(131, stats.maxHealth());
        assertEquals(11, stats.attack());
        assertEquals(66, stats.defense());
        assertEquals(79, stats.speed());
        assertEquals(92, stats.criticalChance());
        assertEquals(11, stats.evadeChance());
        assertEquals(70, stats.accuracy());
    }

    @Test
    void fromGundamSandrockType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.GUNDAM_SANDROCK);
        assertEquals(297, stats.maxHealth());
        assertEquals(64, stats.attack());
        assertEquals(91, stats.defense());
        assertEquals(46, stats.speed());
        assertEquals(91, stats.criticalChance());
        assertEquals(5, stats.evadeChance());
        assertEquals(100, stats.accuracy());
    }

    @Test
    void fromTallgeeseType() {
        GundamStats stats = gundamStatsRepository.fromType(GundamModel.TALLGEESE);
        assertEquals(486, stats.maxHealth());
        assertEquals(41, stats.attack());
        assertEquals(85, stats.defense());
        assertEquals(28, stats.speed());
        assertEquals(48, stats.criticalChance());
        assertEquals(39, stats.evadeChance());
        assertEquals(47, stats.accuracy());
    }

}
